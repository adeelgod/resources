<?php

namespace Revolut\Payment\Api;


interface CreateOrderInterface
{
    /**
     * Returns public_id form revolut
     *
     * @api
     * @return string public_id form revolut.
     */
    public function createOrder();
}
