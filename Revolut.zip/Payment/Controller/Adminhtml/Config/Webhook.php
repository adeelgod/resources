<?php

namespace Revolut\Payment\Controller\Adminhtml\Config;


use Magento\Backend\App\Action;
use Revolut\Payment\Model\ConstantValue;

/**
 * Class Webhook
 * @package Revolut\Payment\Controller\Adminhtml\Config
 */
class Webhook extends Action
{
    /**
     * @var \Revolut\Payment\Helper\ConfigHelper
     */
    protected $configHelper;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Revolut\Payment\Helper\DataHelper
     */
    protected $dataHelper;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;

    /**
     * @var \Magento\Framework\Controller\ResultFactory
     */
    protected $resultFactory;

    /**
     * Webhook constructor.
     * @param Action\Context $context
     * @param \Revolut\Payment\Helper\ConfigHelper $configHelper
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Revolut\Payment\Helper\DataHelper $dataHelper
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param \Magento\Framework\Controller\ResultFactory $resultFactory
     */
    public function __construct(
        Action\Context $context,
        \Revolut\Payment\Helper\ConfigHelper $configHelper,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Revolut\Payment\Helper\DataHelper $dataHelper,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Framework\Controller\ResultFactory $resultFactory
    ) {
        $this->configHelper = $configHelper;
        $this->storeManager = $storeManager;
        $this->dataHelper = $dataHelper;
        $this->jsonHelper = $jsonHelper;
        $this->resultFactory = $resultFactory;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function execute()
    {
        $url = $this->getRequest()->getParam('isTest') ? ConstantValue::URL_SANDBOX : ConstantValue::URL_PROD;
        $apiKeyDataPost = $this->getRequest()->getParam('apiKey');
        $api = strpos($apiKeyDataPost, '***') !== false ? null : $apiKeyDataPost;
        $curl = $url . ConstantValue::API_VER . '/' . ConstantValue::ENDPOINT_WEBHOOK;
        $param = '{"url": "' . $this->storeManager->getStore()->getBaseUrl() . 'revolut/webhook/updateorder","events":["ORDER_COMPLETED","ORDER_AUTHORISED"]}';
        $response = $this->dataHelper->sendRequest($curl, $param, 'POST', $api);
        $response = $this->jsonHelper->jsonDecode($response);
        $data = [
            'error' => true,
        ];
        if (isset($response['id'])) {
            $data = [
                'success' => true,
            ];
        }
        $result = $this->resultFactory->create('json');
        return $result->setData($data);
    }
}
