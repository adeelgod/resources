<?php

namespace Revolut\Payment\Controller\Webhook;


use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\App\RequestInterface;
use Magento\Sales\Model\Order;
use Revolut\Payment\Model\ConstantValue;

/**
 * Class UpdateOrder
 * @package Revolut\Payment\Controller\Webhook
 */
class UpdateOrder extends Action implements CsrfAwareActionInterface
{
    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;

    /**
     * @var \Revolut\Payment\Model\RevolutOrderFactory
     */
    protected $revolutOrderFactory;

    /**
     * @var \Revolut\Payment\Model\ResourceModel\RevolutOrder
     */
    protected $revolutOrderResource;

    /**
     * @var \Revolut\Payment\Helper\Logger
     */
    protected $loggerRevolut;

    /**
     * @var \Magento\Sales\Api\Data\OrderInterface
     */
    protected $orderInterface;

    /**
     * @var \Magento\Sales\Model\Service\InvoiceService
     */
    protected $invoiceService;

    /**
     * @var \Magento\Framework\DB\TransactionFactory
     */
    protected $transactionFactory;

    /**
     * UpdateOrder constructor.
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param \Revolut\Payment\Model\RevolutOrderFactory $revolutOrderFactory
     * @param \Revolut\Payment\Model\ResourceModel\RevolutOrder $revolutOrderResource
     * @param \Revolut\Payment\Helper\Logger $loggerRevolut
     * @param \Magento\Sales\Api\Data\OrderInterface $orderInterface
     * @param \Magento\Sales\Model\Service\InvoiceService $invoiceService
     * @param \Magento\Framework\DB\TransactionFactory $transactionFactory
     * @param Context $context
     */
    public function __construct(
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Revolut\Payment\Model\RevolutOrderFactory $revolutOrderFactory,
        \Revolut\Payment\Model\ResourceModel\RevolutOrder $revolutOrderResource,
        \Revolut\Payment\Helper\Logger $loggerRevolut,
        \Magento\Sales\Api\Data\OrderInterface $orderInterface,
        \Magento\Sales\Model\Service\InvoiceService $invoiceService,
        \Magento\Framework\DB\TransactionFactory $transactionFactory,
        Context $context
    ) {
        $this->jsonHelper = $jsonHelper;
        $this->revolutOrderFactory = $revolutOrderFactory;
        $this->revolutOrderResource = $revolutOrderResource;
        $this->loggerRevolut = $loggerRevolut;
        $this->orderInterface = $orderInterface;
        $this->invoiceService = $invoiceService;
        $this->transactionFactory = $transactionFactory;
        parent::__construct($context);
    }

    /**
     * @inheritDoc
     */
    public function createCsrfValidationException(
        RequestInterface $request
    ): ?InvalidRequestException {
        return null;
    }
    /**
     * @inheritDoc
     */
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
        $response = $this->jsonHelper->jsonDecode($this->_request->getContent());
        $revolutOrderModel = $this->revolutOrderFactory->create();
        $this->revolutOrderResource->load($revolutOrderModel, $response['order_id'], 'revolut_order_id');
        /* @var Order $order*/
        $order = $this->orderInterface->loadByIncrementId($revolutOrderModel->getData('increment_order_id'));
        //if order is paid
        if(!$order->getTotalDue()) {
            return null;
        }
        $payment = $order->getPayment();
        $paymentAction = $payment->getAdditionalInformation('payment_action');
        if (isset($response['order_id']) && $paymentAction == ConstantValue::MAGENTO_AUTHORIZE) {
            if ($response['event'] == ConstantValue::WEBHOOK_EVENT_ORDER_COMPLETED) {
                $payment->setAdditionalInformation('webhook_event_order_completed', true);
                $invoice = $this->invoiceService->prepareInvoice($order);
                $invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_ONLINE);
                $invoice->register();
                $invoice->getOrder()->setCustomerNoteNotify(false);
                $invoice->getOrder()->setIsInProcess(false);
//                $invoice->setState(\Magento\Sales\Model\Order\Invoice::STATE_PAID);
                $invoice->setCanVoidFlag(false);
//                $invoice->canRefund();
                $order->addStatusHistoryComment('Automatically INVOICED', false);
                $transactionSave = $this->transactionFactory->create()->addObject($invoice)->addObject($invoice->getOrder());
                $transactionSave->save();
            }
        }else{
            $this->loggerRevolut->debug("--------------REVOLUT WEBHOOK ORDER COMPLETED EVENT-----------------");
            $this->loggerRevolut->debug($this->_request->getContent());
        }
    }
}
