<?php
/**
 * Copyright © 2020 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 *
 * revolut234 extension
 * NOTICE OF LICENSE
 *
 * @category Magenest
 * @package Magenest_revolut234
 */

namespace Revolut\Payment\Plugin\View;


use Magento\Framework\View\Asset\Minification;

/**
 * Class PreventMinJs
 * @package Revolut\Payment\Plugin\View
 */
class PreventMinJs
{
    /**
     * @param Minification $subject
     * @param array $excludes
     * @param $contentType
     * @return array
     */
    public function afterGetExcludes(Minification $subject, array $excludes, $contentType)
    {
        if ($contentType !== 'js') {
            return $excludes;
        }

        $excludes[] = 'https://sandbox-merchant.revolut.com/embed.js';
        $excludes[] = 'https://merchant.revolut.com/embed.js';
        return $excludes;
    }
}
