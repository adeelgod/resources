<?php

namespace Revolut\Payment\Model\Source;


use Magento\Framework\Option\ArrayInterface;
use Magento\Sales\Model\Order;

class NewOrderStatus implements ArrayInterface
{
    public function toOptionArray()
    {
        return [
            [
                'value' => Order::STATE_PROCESSING,
                'label' => __('Processing')
            ],            [
                'value' => Order::STATUS_FRAUD,
                'label' => __('Suspected Fraud'),
            ]
        ];
    }
}
