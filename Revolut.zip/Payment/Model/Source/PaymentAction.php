<?php

namespace Revolut\Payment\Model\Source;


use Magento\Framework\Option\ArrayInterface;
use Revolut\Payment\Model\ConstantValue;

class PaymentAction implements ArrayInterface
{
    public function toOptionArray()
    {
        return [
            [
                'value' => ConstantValue::MAGENTO_AUTHORIZE_CAPTURE,
                'label' => __('Authorize and Capture')
            ],            [
                'value' => ConstantValue::MAGENTO_AUTHORIZE,
                'label' => __('Authorize Only'),
            ]
        ];
    }
}
