<?php

namespace Revolut\Payment\Model\ResourceModel\RevolutOrder;


use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class Collection extends AbstractCollection
{
    protected $_idFieldName = 'id';

    public function _construct()
    {
        $this->_init('Revolut\Payment\Model\RevolutOrder', 'Revolut\Payment\Model\ResourceModel\RevolutOrder');
    }
}
