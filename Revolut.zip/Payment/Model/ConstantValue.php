<?php

namespace Revolut\Payment\Model;


class ConstantValue
{
    const MODULE_NAME = 'Revolut_Payment';
    const URL_SANDBOX = 'https://sandbox-merchant.revolut.com';
    const URL_PROD = 'https://merchant.revolut.com';
    const API_VER = '/api/1.0';
    const ENDPOINT_ORDER = 'orders';
    const ENDPOINT_CAPTURE_ORDER = 'capture';
    const ENDPOINT_CANCEL_ORDER = 'cancel';
    const ENDPOINT_REFUND_ORDER = 'refund';
    const ENDPOINT_WEBHOOK = 'webhooks';
    const SANDBOX_MODE = 'sandbox';
    const PROD_MODE = 'prod';
    const REVOLUT_AUTHORIZE_ONLY = 'MANUAL';
    const REVOLUT_AUTHORIZE_CAPTURE = 'AUTOMATIC';
    const MAGENTO_AUTHORIZE = 'authorize';
    const MAGENTO_AUTHORIZE_CAPTURE = 'authorize_capture';
    const ORDER_COMPLETED = 'COMPLETED';
    const ORDER_CANCELLED = 'CANCELLED';
    const WEBHOOK_EVENT_ORDER_COMPLETED = 'ORDER_COMPLETED';

    //error code
    const FAILED_CARD = 2005;

    //state revolut order
    const STATE_COMPLETED = 'COMPLETED';
}
