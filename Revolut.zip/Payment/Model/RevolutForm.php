<?php

namespace Revolut\Payment\Model;

use Revolut\Payment\Helper\ConfigHelper;
use Revolut\Payment\Helper\DataHelper;
use Revolut\Payment\Helper\Logger;
use Revolut\Payment\Model\ConstantValue;

/**
 * Class RevolutForm
 * @package Revolut\Payment\Model
 */
class RevolutForm extends \Magento\Payment\Model\Method\Cc
{
    const CODE = 'revolut_form';
    protected $_code = self::CODE;
    protected $_canAuthorize = true;
    protected $_canCapture = true;
    protected $_isGateway = true;
    protected $_canRefund = true;
    protected $_canRefundInvoicePartial = true;
    protected $_canVoid = true;
    protected $_canUseInternal = false;

    /**
     * @var \Magento\Framework\Module\Manager
     */
    protected $moduleManager;

    /**
     * @var ConfigHelper
     */
    protected $configHelper;

    /**
     * @var RevolutOrderFactory
     */
    protected $revolutOrderFactory;

    /**
     * @var DataHelper
     */
    protected $dataHelper;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $managerInterface;

    /**
     * @var Logger
     */
    protected $loggerRevolut;

    /**
     * RevolutForm constructor.
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory
     * @param \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory
     * @param \Magento\Payment\Helper\Data $paymentData
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Payment\Model\Method\Logger $logger
     * @param \Magento\Framework\Module\ModuleListInterface $moduleList
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate
     * @param \Magento\Framework\Module\Manager $moduleManager
     * @param \Magento\Framework\Model\ResourceModel\AbstractResource|null $resource
     * @param \Magento\Framework\Data\Collection\AbstractDb|null $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        \Magento\Framework\Module\ModuleListInterface $moduleList,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $localeDate,
        \Magento\Framework\Module\Manager $moduleManager,
        \Revolut\Payment\Helper\ConfigHelper $configHelper,
        \Revolut\Payment\Model\RevolutOrderFactory $revolutOrderFactory,
        \Revolut\Payment\Helper\DataHelper $dataHelper,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Framework\Message\ManagerInterface $managerInterface,
        \Revolut\Payment\Helper\Logger $loggerRevolut,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    )
    {
        $this->moduleManager = $moduleManager;
        $this->configHelper = $configHelper;
        $this->revolutOrderFactory = $revolutOrderFactory;
        $this->dataHelper = $dataHelper;
        $this->jsonHelper = $jsonHelper;
        $this->managerInterface = $managerInterface;
        $this->loggerRevolut = $loggerRevolut;
        parent::__construct($context, $registry, $extensionFactory, $customAttributeFactory, $paymentData, $scopeConfig, $logger, $moduleList, $localeDate, $resource, $resourceCollection, $data);
    }

    /**
     * @return \Magento\Payment\Model\Method\AbstractMethod|RevolutForm
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function validate()
    {
        return \Magento\Payment\Model\Method\AbstractMethod::validate();
    }

    /**
     * @param \Magento\Quote\Api\Data\CartInterface|null $quote
     * @return bool
     */
    public function isAvailable(\Magento\Quote\Api\Data\CartInterface $quote = null)
    {
        if (!$this->moduleManager->isEnabled(ConstantValue::MODULE_NAME)) {
            return false;
        }
        return \Magento\Payment\Model\Method\AbstractMethod::isAvailable($quote);
    }

    /**
     * @param \Magento\Framework\DataObject $data
     * @return $this|RevolutForm
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function assignData(\Magento\Framework\DataObject $data)
    {
        $infoInstance = $this->getInfoInstance();
        $additionalData = $data->getData('additional_data');
        //log detail payment
        $this->loggerRevolut->debug("---------------------------------------------------------------------------");
        $this->loggerRevolut->debug("Function assignData: "."REVOLUT RESPONSE " . $additionalData['revolutOrder']);

        $infoInstance->setAdditionalInformation('payment_action', $this->configHelper->getConfigValue(ConfigHelper::PAYMENT_ACTION));
        $infoInstance->setAdditionalInformation('publicId', $additionalData['publicId']);
        $infoInstance->setAdditionalInformation('revolutOrderData', $additionalData['revolutOrder']);
        $revolutOrder = $this->jsonHelper->jsonDecode($additionalData['revolutOrder']);
        $infoInstance->setAdditionalInformation('revolutOrderId', $revolutOrder['id']);
        return $this;
    }

    /**
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @param float $amount
     * @return RevolutForm
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function capture(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        if ($payment->getAdditionalInformation('webhook_event_order_completed')){
            return parent::capture($payment, $amount);
        }
        $revolutOrderData = $this->jsonHelper->jsonDecode($payment->getAdditionalInformation('revolutOrderData'));
        // check fraud order
        if (bccomp(round($amount * 100), $revolutOrderData['order_amount']['value'], 2) != 0) {
            $this->loggerRevolut->debug($payment->getOrder()->getIncrementId() . " Revolut Capture Amount Not Same Order Amount");
            $payment->setIsFraudDetected(true);
        }

        $revolutOrderId = $payment->getAdditionalInformation('revolutOrderId');
        $paymentAction = $payment->getAdditionalInformation('payment_action');
        if ($paymentAction == ConstantValue::MAGENTO_AUTHORIZE || $payment->getAdditionalInformation('IsTransactionPending')) {
            //capture when create invoice or payment is transaction pending(the previous capture failed)
            $checkState = $this->checkStateRevolutOrder($revolutOrderId);
            if ($checkState) {
                $curlCaptureOrder = $this->configHelper->getApiUrl() . ConstantValue::API_VER . '/' . ConstantValue::ENDPOINT_ORDER . '/' . $revolutOrderId . '/' . ConstantValue::ENDPOINT_CAPTURE_ORDER;
                $response = $this->dataHelper->sendRequest($curlCaptureOrder);
                //log detail payment
                $this->loggerRevolut->debug($payment->getOrder()->getIncrementId() . " Function capture(capture when submit invoice): "."REVOLUT RESPONSE " . $response);
                $response = $this->jsonHelper->jsonDecode($response);

                //handle error
                if (!isset($response['id'])) {
                    if (isset($response['code'])) {
                        $errorCode = $response['code'];
                        switch ($errorCode) {
                            case ConstantValue::FAILED_CARD:
                                throw new \Magento\Framework\Exception\LocalizedException(__('Customer will not be able to get a capture using this card'));
                                break;
                        }
                    }
                    throw new \Magento\Framework\Exception\LocalizedException(__('Cannot Capture Order - Error Id: ' . $response['errorId']));
                } else {
                    //set revolutOrderId = transactionId because Revoult not return transaction response
                    $payment->setIsTransactionPending(false);
                    $payment->setTransactionId($revolutOrderId);
                    $payment->setShouldCloseParentTransaction(true);
                    $payment->setIsTransactionClosed(true);
                    $payment->setAmount($amount);

                    $orderCurrency = $response['settled_amount']['currency'];
                    $this->managerInterface->addSuccess(__('Capture ' . floatval($response['settled_amount']['value'])/100 . $orderCurrency . ' by Revolut success.'));
                }
            }
        } else{
            //check revolut order has been captured
            $curlRetrieveOrder = $this->configHelper->getApiUrl() . ConstantValue::API_VER . '/' . ConstantValue::ENDPOINT_ORDER . '/' . $revolutOrderId;
            $revolutOrder = $this->dataHelper->sendRequest($curlRetrieveOrder, null, 'GET');
            $revolutOrder = $this->jsonHelper->jsonDecode($revolutOrder);
            if ($revolutOrder['state'] != ConstantValue::STATE_COMPLETED) {
                $payment->setIsTransactionPending(true);
                $payment->setAdditionalInformation('IsTransactionPending', true);
            } else{
                //set revolutOrderId = transactionId because Revoult not return transaction response
                $payment->setTransactionId($revolutOrderId);
                $payment->setShouldCloseParentTransaction(true);
                $payment->setIsTransactionClosed(true);
                $payment->setAmount($amount);
            }
            //save revolut order
            $revolutOrder = $this->revolutOrderFactory->create();
            $revolutOrder->saveRevolutOrder($revolutOrderData, $payment->getOrder()->getIncrementId());
            //log detail payment
            $this->loggerRevolut->debug($payment->getOrder()->getIncrementId() ." Function CAPTURE : SUCCESS");
        }
        return parent::capture($payment, $amount);
    }

    /**
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @param float $amount
     * @return RevolutForm
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function authorize(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $revolutOrderData = $this->jsonHelper->jsonDecode($payment->getAdditionalInformation('revolutOrderData'));
        // check fraud order
        if (bccomp(round($amount * 100), $revolutOrderData['order_amount']['value'], 2) != 0) {
            $this->loggerRevolut->debug($payment->getOrder()->getIncrementId() . " Revolut Authorize Amount Not Same Order Amount");
            $payment->setIsFraudDetected(true);
        }
        //save revolut order
        $revolutOrder = $this->revolutOrderFactory->create();
        $revolutOrder->saveRevolutOrder($revolutOrderData, $payment->getOrder()->getIncrementId());

        $revolutOrderId = $payment->getAdditionalInformation('revolutOrderId');
        $payment->setTransactionId($revolutOrderId)
            ->setIsTransactionClosed(false)
            ->setShouldCloseParentTransaction(false)
            ->setCcTransId($revolutOrderId);
        //log detail payment
        $this->loggerRevolut->debug($payment->getOrder()->getIncrementId() . " Function AUTHORIZE : SUCCESS - ");
        return parent::authorize($payment, $amount);
    }

    /**
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @param float $amount
     * @return RevolutForm
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function refund(\Magento\Payment\Model\InfoInterface $payment, $amount)
    {
        $revolutOrderId = $payment->getAdditionalInformation('revolutOrderId');
        $curlRetrieveOrder = $this->configHelper->getApiUrl() . ConstantValue::API_VER . '/' . ConstantValue::ENDPOINT_ORDER . '/' . $revolutOrderId;
        $revolutOrder = $this->dataHelper->sendRequest($curlRetrieveOrder, null, 'GET');
        $revolutOrder = $this->jsonHelper->jsonDecode($revolutOrder);
        if (!isset($revolutOrder['id'])) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Revolut Order does not exist'));
        } else{
            //check order already REFUND
            $amountRefunded = $revolutOrder['refunded_amount']['value'];
            if ($amountRefunded && $amountRefunded == $revolutOrder['settled_amount']['value']) {
                throw new \Magento\Framework\Exception\LocalizedException(__('Order already REFUND on merchant gateway'));
            }
            $orderCurrency = $revolutOrder['settled_amount']['currency'];
            $curlRefundOrder = $this->configHelper->getApiUrl() . ConstantValue::API_VER . '/' .
                ConstantValue::ENDPOINT_ORDER . '/' . $revolutOrderId . '/' . ConstantValue::ENDPOINT_REFUND_ORDER;
            $paramRefund = [
                "amount" => round($amount * 100),
                "currency" => $orderCurrency
            ];
            $response = $this->dataHelper->sendRequest($curlRefundOrder, $this->jsonHelper->jsonEncode($paramRefund));
            //log detail payment
            $this->loggerRevolut->debug("--------------------------"."REFUND"."-".$payment->getOrder()->getIncrementId()."--------------------------------");
            $this->loggerRevolut->debug($payment->getOrder()->getIncrementId() . " Function refund(refund revolut order): "."REVOLUT RESPONSE " . $response);
            $response = $this->jsonHelper->jsonDecode($response);
            //handle error
            if (!isset($response['id'])) {
                if (isset($response['code'])) {
                    $errorCode = $response['code'];
                    switch ($errorCode) {
                        case ConstantValue::FAILED_CARD:
                            throw new \Magento\Framework\Exception\LocalizedException(__('Customer will not be able to get a refund using this card'));
                            break;
                    }
                }
                throw new \Magento\Framework\Exception\LocalizedException(__('Cannot Cancel Order - Error Id: ' . $response['errorId']));
            } else{
                $this->managerInterface->addSuccess(__('Refund ' . $amount . $orderCurrency . ' by Revolut success.'));
                return parent::refund($payment, $amount);
            }
        }
    }

    /**
     * @param \Magento\Payment\Model\InfoInterface $payment
     * @return RevolutForm
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function cancel(\Magento\Payment\Model\InfoInterface $payment)
    {
        $revolutOrderId = $payment->getAdditionalInformation('revolutOrderId');
        $checkState = $this->checkStateRevolutOrder($revolutOrderId);
        if ($checkState) {
            $curelCancelOrder = $this->configHelper->getApiUrl() . ConstantValue::API_VER . '/' .
                ConstantValue::ENDPOINT_ORDER . '/' . $revolutOrderId . '/' . ConstantValue::ENDPOINT_CANCEL_ORDER;
            $response = $this->dataHelper->sendRequest($curelCancelOrder);
            //log detail payment
            $this->loggerRevolut->debug("--------------------------"."CANCEL"."-".$payment->getOrder()->getIncrementId()."--------------------------------");
            $this->loggerRevolut->debug($payment->getOrder()->getIncrementId() . " Function cancel(cancel revolut order): "."REVOLUT RESPONSE " . $response);
            $response = $this->jsonHelper->jsonDecode($response);

            //handle error
            if (!isset($response['id'])) {
                if (isset($response['code'])) {
                    $errorCode = $response['code'];
                    switch ($errorCode) {
                        case ConstantValue::FAILED_CARD:
                            throw new \Magento\Framework\Exception\LocalizedException(__('Customer will not be able to get a cancel using this card'));
                            break;
                        }
                }
                throw new \Magento\Framework\Exception\LocalizedException(__('Cannot Cancel Order - Error Id: ' . $response['errorId']));
            } else{
                $this->managerInterface->addSuccess(__('Cancel order by Revolut success.'));
                return parent::cancel($payment);
            }
        }
        throw new \Magento\Framework\Exception\LocalizedException(__('Revolut: Cannot Cancel Order'));
    }

    /**
     * @param $revolutOrderId
     * @return bool
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    private function checkStateRevolutOrder($revolutOrderId) {
        //check state revolut order
        $curlRetrieveOrder = $this->configHelper->getApiUrl() . ConstantValue::API_VER . '/' . ConstantValue::ENDPOINT_ORDER . '/' . $revolutOrderId;
        $revolutOrder = $this->dataHelper->sendRequest($curlRetrieveOrder, null, 'GET');
        $revolutOrder = $this->jsonHelper->jsonDecode($revolutOrder);
        if (!isset($revolutOrder['id'])) {
            throw new \Magento\Framework\Exception\LocalizedException(__('Revolut Order does not exist'));
        } else{
            //check order already COMPLETED or CANCEL
            if ($revolutOrder['state'] == ConstantValue::ORDER_COMPLETED || $revolutOrder['state'] == ConstantValue::ORDER_CANCELLED) {
                throw new \Magento\Framework\Exception\LocalizedException(__('Order already ' . $revolutOrder['state'] . ' on merchant gateway'));
            }
            return true;
        }
    }
}
