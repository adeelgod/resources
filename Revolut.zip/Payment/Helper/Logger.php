<?php

namespace Revolut\Payment\Helper;


/**
 * Class Logger
 * @package Revolut\Payment\Helper
 */
class Logger extends \Monolog\Logger
{

}
