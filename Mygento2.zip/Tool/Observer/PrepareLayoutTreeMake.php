<?php
/**
 * Copyright Â© Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
//declare(strict_types=1);

namespace Mygento\Tool\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\View\Layout;
use Mygento\Tool\Helper\Data as HelperData;
use \Magento\Customer\Model\CustomerFactory;
use \Magento\Store\Model\StoreManagerInterface;


class PrepareLayoutTreeMake implements ObserverInterface
{
    protected $_helperData;
    public $customerFactory;
    public $storeManager;

    /**
     * Helper constructor.
     */
    public function __construct(
        HelperData $helperData,
        \Magento\Customer\Model\CustomerFactory $customerFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager
    ) {
        $this->_helperData = $helperData;
        $this->customerFactory = $customerFactory;
        $this->storeManager = $storeManager;
    }

    /**
     * Process event on 'core_layout_render_element' event
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return void
     */


    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        ////////////////////add customer//////////////
        // Get Website ID
        /*$websiteId  = $this->storeManager->getWebsite()->getWebsiteId();

        // Instantiate object (this is the most important part)
        $customer   = $this->customerFactory->create();
        $customer->setWebsiteId($websiteId);

        // Preparing data for new customer
        $customer->setEmail("email@domain.com");
        $customer->setFirstname("Test First");
        $customer->setLastname("Test Last");
        $customer->setPassword("password");

        $customer->save();*/
        //$customer->sendNewAccountEmail();
        //////////////////////////////////////////////
        /////////////////get customer via name//////////
        /*$listCustomer = $this->customerFactory->create()->getCollection()
            ->addAttributeToSelect("*")
            ->addAttributeToFilter("firstname", array("eq" => "Veronica"))
            ->load();*/
        /// ////////////////////////////////////////////
        if(!$this->_helperData->isHint()) {
            return;
        }

        $elementName = $observer->getEvent()->getElementName();
        $layout = $observer->getEvent()->getLayout();
        $transport = $observer->getEvent()->getTransport();

        $html = $transport->getData('output');

        $data = ['name' => $elementName, 'html' => $html];
        $this->_helperData->appendNodeToLayoutTree($data);


        if(!$this->_helperData->isNodeInBlockList($elementName)) {
            $id = str_replace(".", "__", $elementName);
            $html = "<div id='dev_hint_layout_{$id}'>{$html}</div>";
            $transport->setData('output', $html);
        }

    }
}
