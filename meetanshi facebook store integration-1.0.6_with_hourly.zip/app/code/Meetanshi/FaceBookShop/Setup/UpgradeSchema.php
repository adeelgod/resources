<?php

namespace Meetanshi\FaceBookShop\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\App\ObjectManager;

class UpgradeSchema implements UpgradeSchemaInterface
{
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        try {
            $installer = $setup;
            $installer->startSetup();
            $add = false;
            //if (version_compare($context->getVersion(), '1.0.4', '<')) {
                if ($installer->getConnection()->tableColumnExists('meetanshi_facebook_feed_report', 'store_name') === false) {
                    $installer->getConnection()
                        ->addColumn(
                            $installer->getTable('meetanshi_facebook_feed_report'),
                            'store_name',
                            [
                                'type' => Table::TYPE_TEXT,
                                'size' => 200,
                                'nullable' => true,
                                'comment' => 'Store Name'
                            ]
                        );
                    $add = true;
                }

                if ($installer->getConnection()->tableColumnExists('meetanshi_facebook_feed_report', 'csv_file') === false) {
                    $installer->getConnection()
                        ->addColumn(
                            $installer->getTable('meetanshi_facebook_feed_report'),
                            'csv_file',
                            [
                                'type' => Table::TYPE_TEXT,
                                'size' => 250,
                                'nullable' => true,
                                'comment' => 'File Name'
                            ]
                        );
                }

                if ($add) {
                    $installer->getConnection()->addIndex(
                        $installer->getTable('meetanshi_facebook_feed_report'),
                        $setup->getIdxName(
                            $installer->getTable('meetanshi_facebook_feed_report'),
                            ['store_name'],
                            AdapterInterface::INDEX_TYPE_FULLTEXT
                        ),
                        ['store_name'],
                        AdapterInterface::INDEX_TYPE_FULLTEXT
                    );
                }
            //}
            $setup->endSetup();

        } catch (\Exception $e) {
            ObjectManager::getInstance()->get('Psr\Log\LoggerInterface')->info($e->getMessage());
        }
    }
}
