<?php

namespace Meetanshi\FaceBookShop\Block\Adminhtml\Facebookshop\Edit;

use Magento\Backend\Block\Template\Context;
use Magento\Backend\Block\Widget\Form\Generic;
use Magento\Framework\Registry;
use Magento\Framework\Data\FormFactory;
use Magento\Cms\Model\Wysiwyg\Config;
use Magento\Store\Model\System\Store;
use Meetanshi\FaceBookShop\Helper\Data;

/**
 * Class Form
 * @package Meetanshi\FaceBookShop\Block\Adminhtml\Facebookshop\Edit
 */
class Form extends Generic
{
    /**
     * @var Store
     */
    protected $systemStore;
    /**
     * @var
     */
    protected $logger;
    /**
     * @var
     */
    protected $options;
    /**
     * @var Data
     */
    private $helper;

    /**
     * Form constructor.
     * @param Context $context
     * @param Registry $registry
     * @param FormFactory $formFactory
     * @param Config $wysiwygConfig
     * @param Store $store
     * @param Data $helper
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        FormFactory $formFactory,
        Config $wysiwygConfig,
        Store $store,
        Data $helper,
        array $data = []
    )
    {
        $this->_wysiwygConfig = $wysiwygConfig;
        $this->systemStore = $store;
        $this->helper = $helper;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * @return Generic
     */
    protected function _prepareForm()
    {
        try {
            $model = $this->_coreRegistry->registry('row_data');
            $form = $this->_formFactory->create(
                ['data' => [
                    'id' => 'edit_form',
                    'enctype' => 'multipart/form-data',
                    'action' => $this->getData('action'),
                    'method' => 'post'
                ]
                ]
            );
            $form->setHtmlIdPrefix('wkgrid_');
            if ($model->getId()) {
                $fieldset = $form->addFieldset(
                    'base_fieldset',
                    ['legend' => __('Change Attribute'), 'class' => 'fieldset-wide']
                );
                $fieldset->addField('id', 'hidden', ['name' => 'id']);
            } else {
                $fieldset = $form->addFieldset(
                    'base_fieldset',
                    ['legend' => __('Add Attribute'), 'class' => 'fieldset-wide']
                );
            }
            $action = $fieldset->addField(
                'facebook_attribute_code',
                'select',
                [
                    'name' => 'facebook_attribute_code',
                    'label' => __('Facebook Attribute Code'),
                    'id' => 'facebook_attribute_code',
                    'title' => __('Facebook Attribute Code'),
                    'class' => 'required-entry',
                    'required' => true,
                    'values' => $this->helper->getFacebookAttribute(),
                ]
            );

            $anotherField = $fieldset->addField(
                "custom_option",
                "text",
                [
                    "label" => __("Facebook Custom Option"),
                    "class" => "required-entry",
                    "required" => true,
                    "name" => "custom_option",
                ]
            );

            $this->setChild(
                'form_after',
                $this->getLayout()->createBlock('\Magento\Backend\Block\Widget\Form\Element\Dependence')
                    ->addFieldMap($action->getHtmlId(), $action->getName())
                    ->addFieldMap($anotherField->getHtmlId(), $anotherField->getName())
                    ->addFieldDependence($anotherField->getName(), $action->getName(), 'custom_option')
            );

            $fieldset->addField(
                'magento_attribute_code',
                'select',
                [
                    'name' => 'magento_attribute_code',
                    'label' => __('Magento Attribute Code'),
                    'id' => 'magento_attribute_code',
                    'title' => __('Magento Attribute Code'),
                    'class' => 'required-entry',
                    'required' => true,
                    'values' => $this->helper->getProductAttribute(),
                    'note' => 'For image attribute, minimum size must be 600 x 600 pixels.',
                ]
            );
            $form->setValues($model->getData());
            $form->setUseContainer(true);
            $this->setForm($form);
            return parent::_prepareForm();
        } catch (\Exception $e) {
            $this->helper->logMessage($e->getMessage());
        }
    }
}
