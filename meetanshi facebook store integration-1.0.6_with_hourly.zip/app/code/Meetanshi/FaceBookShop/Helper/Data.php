<?php

namespace Meetanshi\FaceBookShop\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Store\Model\ScopeInterface;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Framework\Filesystem;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\CatalogInventory\Model\Stock\StockItemRepository;
use Magento\Framework\UrlInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Meetanshi\FaceBookShop\Model\ResourceModel\Facebookshop\CollectionFactory;
use Meetanshi\FaceBookShop\Model\ReportFactory;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollection;
use Magento\ConfigurableProduct\Model\Product\Type\Configurable;
use Magento\Catalog\Model\ProductFactory;
use Magento\Catalog\Model\ResourceModel\Product\Attribute\CollectionFactory as AttributeCollection;
use Magento\CatalogInventory\Api\StockStatusCriteriaInterfaceFactory;
use Magento\CatalogInventory\Api\StockStatusRepositoryInterface;
use Magento\Catalog\Model\Product;
use Magento\Framework\Filesystem\Io\File;
use Magento\CatalogInventory\Api\StockRegistryInterface;
use Magento\Framework\App\ProductMetadataInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Catalog\Model\ProductRepository;
use Magento\Catalog\Helper\Data as TaxHelper;
use Magento\Bundle\Model\Product\Type;
use Magento\GroupedProduct\Model\Product\Type\Grouped;
use Magento\Catalog\Model\Product\Visibility;
use Magento\Catalog\Model\Product\Attribute\Source\Status;

/**
 * Class Data
 * @package Meetanshi\FaceBookShop\Helper
 */
class Data extends AbstractHelper
{
    const ENABLE_SCHEDULE = 'facebook_shop/general/enable_schedule';
    const FREQUENCY = 'facebook_shop/general/frequency';
    const START_TIME = 'facebook_shop/general/time';
    const REMOVE_OUTOFSTOCK_PRODUCT = 'facebook_shop/general/remove_outofstock_product';
    const CATALOG_RULES = 'facebook_shop/general/apply_catalog_rules';
    const REMOVE_PUB_DIR = 'facebook_shop/general/remove_pub';
    const PRODUCT_URL = 'facebook_shop/general/product_url';
    const PRODUCT_SPECIAL_PRICE = 'facebook_shop/general/add_sales_price';
    const PRODUCT_WITH_TAX = 'facebook_shop/general/price_with_tax';
    const SELECTED_STORES = 'facebook_shop/general/store_view';
    const ADD_ALL_PRODUCTS = 'facebook_shop/general/add_all_products';
    const IS_STORE_SPECIFIC = 'facebook_shop/general/is_store_specific';

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var array
     */
    protected $result = [];
    /**
     * @var Collection
     */
    private $productCollection;
    /**
     * @var Filesystem
     */
    private $fileSystem;
    /**
     * @var FileFactory
     */
    private $fileFactory;
    /**
     * @var StockItemRepository
     */
    private $stockItemRepository;
    /**
     * @var CollectionFactory
     */
    private $attributeCollection;
    /**
     * @var ReportFactory
     */
    private $reportFactory;
    /**
     * @var TimezoneInterface
     */
    private $dateTime;
    /**
     * @var Configurable
     */
    private $configurable;
    /**
     * @var ProductFactory
     */
    private $productFactory;
    /**
     * @var AttributeCollection
     */
    private $productAttributes;

    /**
     * @var CategoryFactory
     */
    private $categoryFactory;

    /**
     * @var CategoryCollection
     */
    private $categoryCollection;

    /**
     * @var \Magento\Catalog\Model\CategoryRepository
     */
    private $categoryRepository;

    /**
     * @var StockStatusCriteriaInterfaceFactory
     */
    private $stockStatusCriteriaInterfaceFactory;

    /**
     * @var StockStatusRepositoryInterface
     */
    private $stockStatusRepositoryInterface;

    /**
     * @var Product
     */
    protected $product;
    /**
     * @var Type
     */
    protected $bundle;
    /**
     * @var Grouped
     */
    protected $grouped;
    /**
     * @var File
     */
    protected $filesystemIo;
    /**
     * @var DirectoryList
     */
    protected $directoryList;
    /**
     * @var StockRegistryInterface
     */
    protected $stockRegistryInterface;
    /**
     * @var ProductMetadataInterface
     */
    protected $getMagentoVersion;

    /**
     * @var \Magento\InventorySalesApi\Api\StockResolverInterface
     */
    public $stockResolver;

    /**
     * @var \Magento\Catalog\Model\ProductRepository
     */
    protected $productRepository;

    /**
     * @var \Magento\InventorySalesApi\Api\IsProductSalableInterface
     */
    public $isProductSalable;

    protected $moduleManager;

    /**
     * @var \Magento\Catalog\Helper\Data
     */
    protected $taxHelper;

    protected $productSalableQty;
    /**
     * Data constructor.
     * @param Context $context
     * @param StoreManagerInterface $StoreManagerInterface
     * @param Collection $productCollection
     * @param Filesystem $filesystem
     * @param FileFactory $fileFactory
     * @param StockItemRepository $stockItemRepository
     * @param CollectionFactory $facebookShopFactory
     * @param ReportFactory $reportFactory
     * @param TimezoneInterface $timezone
     * @param Configurable $configurable
     * @param ProductFactory $productFactory
     * @param AttributeCollection $productAttributes
     * @param CategoryFactory $categoryFactory
     * @param CategoryCollection $collectionFactory
     * @param \Magento\Catalog\Model\CategoryRepository $categoryRepository
     * @param StockStatusCriteriaInterfaceFactory $stockStatusCriteriaInterfaceFactory
     * @param StockStatusRepositoryInterface $stockStatusRepository
     * @param Product $product
     * @param File $filesystemIo
     * @param DirectoryList $directoryList
     * @param StockRegistryInterface $stockRegistry
     * @param ProductMetadataInterface $metadata
     * @param ProductRepository $productRepository
     * @param TaxHelper $taxHelper
     * @param Type $bundle
     * @param Grouped $grouped
     */
    public function __construct(
        Context $context,
        StoreManagerInterface $StoreManagerInterface,
        Collection $productCollection,
        Filesystem $filesystem,
        FileFactory $fileFactory,
        StockItemRepository $stockItemRepository,
        CollectionFactory $facebookShopFactory,
        ReportFactory $reportFactory,
        TimezoneInterface $timezone,
        Configurable $configurable,
        ProductFactory $productFactory,
        AttributeCollection $productAttributes,
        CategoryFactory $categoryFactory,
        CategoryCollection $collectionFactory,
        \Magento\Catalog\Model\CategoryRepository $categoryRepository,
        StockStatusCriteriaInterfaceFactory $stockStatusCriteriaInterfaceFactory,
        StockStatusRepositoryInterface $stockStatusRepository,
        Product $product,
        File $filesystemIo,
        DirectoryList $directoryList,
        StockRegistryInterface $stockRegistry,
        ProductMetadataInterface $metadata,
        ProductRepository $productRepository,
        TaxHelper $taxHelper,
        Type $bundle,
        Grouped $grouped
    )
    {
        $this->storeManager = $StoreManagerInterface;
        $this->productCollection = $productCollection;
        $this->fileSystem = $filesystem;
        $this->fileFactory = $fileFactory;
        $this->stockItemRepository = $stockItemRepository;
        $this->attributeCollection = $facebookShopFactory;
        $this->reportFactory = $reportFactory;
        $this->dateTime = $timezone;
        $this->configurable = $configurable;
        $this->productFactory = $productFactory;
        $this->productAttributes = $productAttributes;
        $this->categoryFactory = $categoryFactory;
        $this->categoryCollection = $collectionFactory;
        $this->categoryRepository = $categoryRepository;
        $this->stockStatusCriteriaInterfaceFactory = $stockStatusCriteriaInterfaceFactory;
        $this->stockStatusRepositoryInterface = $stockStatusRepository;
        $this->product = $product;
        $this->filesystemIo = $filesystemIo;
        $this->directoryList = $directoryList;
        $this->stockRegistryInterface = $stockRegistry;
        $this->getMagentoVersion = $metadata;
        $this->productRepository = $productRepository;
        $this->taxHelper = $taxHelper;
        $this->bundle = $bundle;
        $this->grouped = $grouped;
        $this->moduleManager = $context->getModuleManager();
        parent::__construct($context);
    }

    /**
     * @return mixed
     */
    public function getFrequency()
    {
        return $this->scopeConfig->getValue(self::FREQUENCY, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function getStartTime()
    {
        return $this->scopeConfig->getValue(self::START_TIME, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function isEnableSchedule()
    {
        return $this->scopeConfig->getValue(self::ENABLE_SCHEDULE, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @return mixed
     */
    public function isRemoveOutOfStockProduct()
    {
        return $this->scopeConfig->getValue(self::REMOVE_OUTOFSTOCK_PRODUCT, ScopeInterface::SCOPE_STORE);
    }

    /**
     * @param null $storeID
     * @return mixed
     */
    public function isCatalogPriceRule($storeID = null)
    {
        return $this->scopeConfig->getValue(self::CATALOG_RULES, ScopeInterface::SCOPE_STORE, $storeID);
    }

    /**
     * @param null $storeID
     * @return mixed
     */
    public function isRemovePubDir($storeID = null)
    {
        return $this->scopeConfig->getValue(self::REMOVE_PUB_DIR, ScopeInterface::SCOPE_STORE, $storeID);
    }

    /**
     * @param null $storeID
     * @return mixed
     */
    public function isProductWithTax($storeID = null)
    {
        return $this->scopeConfig->getValue(self::PRODUCT_WITH_TAX, ScopeInterface::SCOPE_STORE, $storeID);
    }

    /**
     * @param null $storeID
     * @return mixed
     */
    public function isProductURL($storeID = null)
    {
        return $this->scopeConfig->getValue(self::PRODUCT_URL, ScopeInterface::SCOPE_STORE, $storeID);
    }

    /**
     * @param null $storeID
     * @return mixed
     */
    public function isSalesPrice($storeID = null)
    {
        return $this->scopeConfig->getValue(self::PRODUCT_SPECIAL_PRICE, ScopeInterface::SCOPE_STORE, $storeID);
    }

    /**
     * @param null $storeID
     * @return mixed
     */
    public function getSelectedStores($storeID = null)
    {
        return $this->scopeConfig->getValue(self::SELECTED_STORES, ScopeInterface::SCOPE_STORE, $storeID);
    }

    /**
     * @param null $storeID
     * @return mixed
     */
    public function isAddAllProducts($storeID = null)
    {
        return $this->scopeConfig->getValue(self::ADD_ALL_PRODUCTS, ScopeInterface::SCOPE_STORE, $storeID);
    }

    /**
     * @param null $storeID
     * @return mixed
     */
    public function isStoreSpecific($storeID = null)
    {
        return $this->scopeConfig->getValue(self::IS_STORE_SPECIFIC, ScopeInterface::SCOPE_STORE, $storeID);
    }

    /**
     * @param $status
     * @param $store
     * @return int
     */
    public function configGenerateCsv($status, $store = null)
    {
        $objectManager = ObjectManager::getInstance();

        if ($this->moduleManager->isEnabled('Magento_InventorySalesApi')) {
            $isProductSalable = $objectManager->create(\Magento\InventorySalesApi\Api\IsProductSalableInterface::class);
            $stockResolver = $objectManager->create(\Magento\InventorySalesApi\Api\StockResolverInterface::class);
            $productSalableQty = $objectManager->create(\Magento\InventorySalesApi\Api\GetProductSalableQtyInterface::class);

            $this->isProductSalable = $isProductSalable;
            $this->stockResolver = $stockResolver;
            $this->productSalableQty = $productSalableQty;
        } else {
            $this->stockResolver = null;
            $this->isProductSalable = null;
            $this->productSalableQty = null;
        }

        $reportData = $this->reportFactory->create();
        $startedTime = $this->dateTime->date()->format('Y-m-d H:i:s');
        $productIds = [];
        $parent = '';
        $fileName = 'FBProductUpload';
        $storeName = null;

        try {
            $directory = $this->fileSystem->getDirectoryWrite(DirectoryList::PUB);

            if ($this->isRemoveOutOfStockProduct($store)) {
                $collection = $this->productCollection->addAttributeToSelect('*');
            } else {
                $collection = $this->productCollection->addAttributeToSelect('*')
                    ->setFlag('has_stock_status_filter', false);
            }

            if (!$this->isAddAllProducts($store)){
                $collection = $collection->addAttributeToFilter('enable_fb_product', array('eq' => '1'));
            }
            $collection = $collection->load();

            if ($store != null){
                $storeName = $this->storeManager->getStore($store)->getName();
                $this->storeManager->setCurrentStore($store);
                $collection = $collection->addStoreFilter($store);
                $fileName = 'FBProductUpload-'.$storeName;
            }

            $baseCurrency = $this->storeManager->getStore()->getBaseCurrency()->getCode();
            $this->storeManager->getStore()->setCurrentCurrencyCode($baseCurrency);

            $fileName = str_replace(' ','_',trim($fileName));

            $filePath = "media/$fileName.csv";
            $directory->create('media');
            $stream = $directory->openFile($filePath, 'w+');
            $stream->lock();
            $columns = ['id', 'title', 'description', 'availability', 'condition', 'price', 'link', 'image_link', 'brand', 'item_group_id', 'google_product_category', 'additional_image_link'];
            $attributeOption = $this->attributeCollection->create()->load();
            $magAttribute = [];
            $idAttribute = '';
            $titleAttribute = '';
            $descAttribute = '';
            $imageAttribute = '';
            $brandAttribute = '';
            $urlAttribute = '';
            $conditionAttribute = '';
            $productBrand = '';
            $additionalImageUrlAttribute = null;
            $inventoryAttribute = null;
            $googleCategoryAttribute = null;

            foreach ($attributeOption as $attribute) {
                if (!in_array($attribute->getData('facebook_attribute_code'), $columns)) {
                    array_push($columns, $attribute->getData('facebook_attribute_code'));
                    array_push($magAttribute, $attribute->getData('magento_attribute_code'));
                }

                if ($attribute->getData('facebook_attribute_code') == 'id') {
                    $idAttribute = $attribute->getData('magento_attribute_code');
                }
                if ($attribute->getData('facebook_attribute_code') == 'title') {
                    $titleAttribute = $attribute->getData('magento_attribute_code');
                }
                if ($attribute->getData('facebook_attribute_code') == 'description') {
                    $descAttribute = $attribute->getData('magento_attribute_code');
                }
                if ($attribute->getData('facebook_attribute_code') == 'image_link') {
                    $imageAttribute = $attribute->getData('magento_attribute_code');
                }
                if ($attribute->getData('facebook_attribute_code') == 'brand') {
                    $brandAttribute = $attribute->getData('magento_attribute_code');
                }
                if ($attribute->getData('facebook_attribute_code') == 'condition') {
                    $conditionAttribute = $attribute->getData('magento_attribute_code');
                }
                if ($attribute->getData('facebook_attribute_code') == 'link') {
                    $urlAttribute = $attribute->getData('magento_attribute_code');
                }
                if ($attribute->getData('facebook_attribute_code') == 'additional_image_link') {
                    $additionalImageUrlAttribute = $attribute->getData('magento_attribute_code');
                }
                if ($attribute->getData('facebook_attribute_code') == 'inventory') {
                    $inventoryAttribute = $attribute->getData('magento_attribute_code');
                }
                if ($attribute->getData('facebook_attribute_code') == 'google_product_category') {
                    $googleCategoryAttribute = $attribute->getData('magento_attribute_code');
                }
            }

            if ($this->isSalesPrice()) {
                array_push($columns, 'sale_price');
                array_push($columns, 'sale_price_effective_date');
            }
            array_push($columns, 'inventory');

            foreach ($columns as $column) {
                $header[] = $column;
            }
            /* Write Header */
            $stream->writeCsv($header);
            $products = [];
            $i = 0;
            $productStatus = Status::STATUS_ENABLED;

            foreach ($collection as $product) {
                try {
                    /** @var $product \Magento\Catalog\Model\Product */

                    if ($product->getStatus() == $productStatus) {
                        if ($product->getTypeId() != 'configurable' && $product->getTypeId() != 'bundle' && $product->getTypeId() != 'grouped') {
                            $productSId = null;
                            if ($store == null) {
                                $storeIds = $product->getStoreIds();
                                foreach ($storeIds as $storeId) {
                                    $productSId = $storeId;
                                }
                            }else{
                                $productSId = $store;
                            }

                            //currentStore = $this->storeManager->getStore();
                            $currentStore = $this->storeManager->getStore($productSId);
                            $mediaUrl = $currentStore->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);

                            if ($this->isRemovePubDir($productSId)) {
                                $mediaUrl = str_replace('pub/', '', $mediaUrl);
                            }

                            $stock = $this->getProductAvailableStatus($product->getId(), $product->getSku());
                            if ($this->isRemoveOutOfStockProduct()) {
                                if ($stock != 'in stock'){
                                    continue;
                                }
                            }
                            $additionalImageUrl = '';
                            $configSku = '';
                            $parent = '';
                            $productConfig = null;
                            $ProductMediaUrl = '';

                            $parentIds = $this->getProductParentIds($product->getId());
                            //$parentIds = $this->configurable->getParentIdsByChild($product->getId());
                            if ($googleCategoryAttribute == null) {
                                $category = $product->getData('google_product_category');
                            }else{
                                $category = $product->getAttributeText($googleCategoryAttribute);
                            }

                            if ($parentIds != null) {
                                $parentId = array_shift($parentIds);
                                /** @var $productConfig \Magento\Catalog\Model\Product */
                                $productConfig = $this->productFactory->create()->load($parentId);
                                $configSku = $productConfig->getSku();
                                $parent = $parentId;

                                if ($category == null) {
                                    $category = $this->getCategory($productConfig);
                                }
                            } else {
                                if ($category == null) {
                                    $category = $this->getCategory($product);
                                }
                            }

                            if ($product->getTypeId() == 'grouped' || $product->getTypeId() == 'bundle') {
                                $price = $product->getPriceInfo()->getPrice('final_price')->getMinimalPrice()->getValue();
                                $parent = '';
                            } else {
                                if ($this->isCatalogPriceRule($productSId)) {
                                    $price = $product->getPriceInfo()->getPrice('final_price')->getAmount()->getValue();
                                } else {
                                    $price = $product->getFinalPrice();
                                }
                            }

                            if ($this->isProductWithTax($productSId)) {
                                $price = $this->taxHelper->getTaxPrice($product, $price, true);
                                if (is_numeric($price)) {
                                    $price = number_format($price, 2);
                                }
                            } else {
                                if (is_numeric($price)) {
                                    $price = number_format($price, 2);
                                }
                            }

                            $child = $product->getId();
                            $storeUrl = null;
                            $productStoreId = $productSId;
                            $storeUrl = $this->scopeConfig->getValue('web/secure/base_url', ScopeInterface::SCOPE_STORE, $productSId);
                            $url = $this->storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_WEB);

                            if ($storeUrl == null) {
                                $storeUrl = $url;
                            }

                            if ($this->isProductURL()) {
                                $notVisible = Visibility::VISIBILITY_NOT_VISIBLE;
                                if ($product->getVisibility() == $notVisible && $parent != ''){
                                    $productConfig->setStoreId($productStoreId);
                                    $url = $productConfig->getProductUrl();
                                }else {
                                    $product->setStoreId($productStoreId);
                                    $url = $product->getProductUrl();
                                }

                                $strPosition = strpos($url, '?');

                                if ($strPosition !== false) {
                                    $url = substr($url, 0, $strPosition);
                                }
                            } else {
                                if ($productSId == null) {
                                    $productSId = '';
                                }
                                if ($parent != '' && $productConfig != null){
                                    if ($productConfig->getTypeId() == 'configurable'){
                                        $url = $storeUrl . 'facebookshop/addcart/index/parentid/' . $parent . '/productid/' . $child . '/storeid/' . $productSId;
                                    }else{
                                        $url = $storeUrl . 'facebookshop/addcart/index/bgparentid/' . $parent . '/productid/' . $child . '/storeid/' . $productSId;
                                    }
                                }else{
                                    $url = $storeUrl . 'facebookshop/addcart/index/productid/' . $child . '/storeid/' . $productSId;
                                }
                            }

                            $productCondition = $product->getProductCondition();
                            if ($productCondition == null) {
                                $productCondition = 'new';
                            }
                            $productId = $product->getSku();
                            $productTitle = $product->getName();
                            $productDesc = strip_tags($product->getDescription());

                            if ($productDesc == null && $parent != ''){
                                $productDesc = strip_tags($productConfig->getDescription());
                            }

                            if ($product->getData('image') != null) {
                                $ProductMediaUrl = $mediaUrl . 'catalog/product' . $product->getData('image');
                            }elseif ($parent != ''){
                                $ProductMediaUrl = $mediaUrl . 'catalog/product' . $productConfig->getData('image');
                            }

                            if ($idAttribute != null) {
                                $productId = $product->getData($idAttribute);
                            }
                            if ($titleAttribute != null) {
                                $productTitle = $product->getData($titleAttribute);
                            }
                            if ($descAttribute != null) {
                                if ($product->getData($descAttribute) != '') {
                                    $productDesc = $product->getData($descAttribute);
                                } elseif ($parent != '') {
                                    $productDesc = $productConfig->getData($descAttribute);
                                }
                            }
                            if ($imageAttribute != null) {
                                if ($product->getData($imageAttribute) != '') {
                                    $ProductMediaUrl = $mediaUrl . 'catalog/product' . $product->getData($imageAttribute);
                                } elseif ($parent != '') {
                                    $ProductMediaUrl = $mediaUrl . 'catalog/product' . $productConfig->getData($imageAttribute);
                                }
                            }
                            if ($brandAttribute != null) {
                                $productBrand = $product->getAttributeText($brandAttribute);
                            }
                            if ($urlAttribute != null) {
                                $url = $product->getData($urlAttribute);
                            }
                            if ($conditionAttribute != null) {
                                $productCondition = $product->getResource()->getAttribute($conditionAttribute)->getFrontend()->getValue($product);
                            }

                            if ($productDesc == '' || $productDesc == null) {
                                if ($descAttribute == 'description') {
                                    $productDesc = $product->getData('short_description');
                                } else {
                                    $productDesc = $product->getData('description');
                                }
                                if ($productDesc == '' || $productDesc == null) {
                                    $productDesc = $productTitle;
                                }
                            }

                            if ($productBrand == null || !isset($productBrand) || trim($productBrand) === '') {
                                $productBrand = 'brand';
                            }

                            $productDesc = strtolower($productDesc);
                            $productDesc = ucfirst($productDesc);
                            $productDesc = strip_tags($productDesc);
                            $productDesc = trim(preg_replace('/\s\s+/', ' ', $productDesc));
                            $productDesc = substr($productDesc, 0, 4999);

                            $productTitle = substr($productTitle, 0, 149);

                            if ($additionalImageUrlAttribute == null) {
                                $additionalImageUrl = $this->getProductAdditionalImageUrl($product, $ProductMediaUrl, $productStoreId);
                            } else {
                                $additionalImageUrl = $product->getData($additionalImageUrlAttribute);
                            }

                            $specialPricee = null;
                            $pricee = $price;
                            if ($this->isSalesPrice()) {
                                $specialPricee = $product->getPriceInfo()->getPrice('special_price')->getAmount()->getValue();
                                if ($specialPricee != null && $price < $specialPricee){
                                    if (is_numeric($specialPricee)) {
                                        $price = number_format($specialPricee, 2);
                                    }
                                }elseif ($price == $specialPricee){
                                    if (is_numeric($product->getPriceInfo()->getPrice('regular_price')->getAmount()->getValue())) {
                                        $price = number_format($product->getPriceInfo()->getPrice('regular_price')->getAmount()->getValue());
                                    }
                                }
                            }

                            /* check brand valid string */
                            $productBrand = $this->formatText($productBrand, 90);

                            $products[$i] = array($productId, $productTitle, strip_tags($productDesc), $stock, $productCondition, $price, $url, $ProductMediaUrl, $productBrand, $configSku, $category, $additionalImageUrl);
                            $productIds[$i] = $product->getId();

                            foreach ($magAttribute as $value) {
                                //$productt = $this->product->load($product->getId());
                                $option = $product->getAttributeText($value);
                                array_push($products[$i], $option);
                            }

                            if ($this->isSalesPrice()) {
                                $specialDate = '';
                                $specialFromDate = $product->getData('special_from_date');
                                if ($specialFromDate) {
                                    $specialDate = $this->getSpecialPriceDate($specialFromDate);
                                }
                                if ($specialFromDate) {
                                    $specialDate .= '/';
                                }
                                $specialToDate = $product->getData('special_to_date');
                                if ($specialToDate) {
                                    $specialDate .= $this->getSpecialPriceDate($specialToDate);
                                }
                                $specialPrice = $product->getPriceInfo()->getPrice('special_price')->getAmount()->getValue();
                                if ($specialPrice == null) {
                                    $specialPrice = $product->getSpecialPrice();
                                }
                                if ($pricee < $specialPrice){
                                    $specialPrice = $pricee;
                                }
                                if ($specialPrice != null || !empty($specialPrice)){
                                    if (is_numeric($specialPrice)) {
                                        $specialPrice = number_format($specialPrice, 2);
                                    }
                                }
                                 array_push($products[$i], $specialPrice);
                                 array_push($products[$i], $specialDate);
                            }

                            if ($inventoryAttribute == null) {
                                $qty = $this->getProductQty($product->getId(), $product->getSku());
                            }else{
                                $qty = $product->getAttributeText($inventoryAttribute);
                            }
                            array_push($products[$i], $qty);

                            $i++;
                        }
                    }
                } catch (\Exception $e) {
                    $this->logMessage($e->getMessage());
                    $this->logMessage('--- product --- ' . $product->getId());
                }
            }

            foreach ($products as $item) {
                $itemData = [];
                for ($j = 0; $j < sizeof($item); $j++) {
                    $itemData[] = $item[$j];
                }
                $stream->writeCsv($itemData);
            }

            try {
                $content = [];
                $content['type'] = 'filename';
                $content['value'] = $filePath;
                $content['rm'] = '0';

                $csvFileName = 'FBUpload.csv';
                //$this->fileFactory->create($csvFileName, $content, DirectoryList::PUB);

                $finishedTime = $this->dateTime->date()->format('Y-m-d H:i:s');
                $cnt = sizeof($productIds);

                $reportData->setStartedAt($startedTime);
                $reportData->setFinishedAt($finishedTime);
                $reportData->setTriggeredBy($status);
                if ($cnt > 40) {
                    $lastPId = end($productIds);
                    $productIds = array_slice($productIds, 0, 39);
                    $reportData->setProductIds(implode(",", $productIds) . ',...,' . $lastPId);
                } else {
                    $reportData->setProductIds(implode(",", $productIds));
                }
                $reportData->setStatus('success');
                $reportData->setMessage("CSV created successfully at pub/media/$fileName.csv");
                $reportData->setStoreName($storeName);
                $reportData->setCsvFile("$fileName.csv");
                $reportData->save();

                $directory->create('media/' . $reportData->getId());
                $dir = $this->directoryList->getPath('pub') . "/media/$fileName.csv";
                $dir2 = $this->directoryList->getPath('pub') . '/media/' . $reportData->getId() . "/$fileName.csv";
                $this->filesystemIo->cp($dir, $dir2);
            } catch (\Exception $e) {
                $this->_logger->info($e->getMessage());
                return 0;
            }
            return 1;
        } catch (\Exception $e) {
            $cnt = sizeof($productIds);
            $finishedTime = $this->dateTime->date()->format('Y-m-d H:i:s');
            $reportData->setStartedAt($startedTime);
            $reportData->setFinishedAt($finishedTime);
            $reportData->setTriggeredBy($status);
            if ($cnt > 40) {
                $lastPId = end($productIds);
                $productIds = array_slice($productIds, 0, 39);
                $reportData->setProductIds(implode(",", $productIds) . ',...,' . $lastPId);
            } else {
                $reportData->setProductIds(implode(",", $productIds));
            }
            $reportData->setStatus('error');
            $reportData->setMessage("Unable to create CSV at pub/media/$fileName.csv");
            $reportData->setStoreName($storeName);
            $reportData->setCsvFile("$fileName.csv");
            $reportData->save();
            $this->_logger->info($e->getMessage());
            return 0;
        }
    }

    /**
     * @param $product
     * @return string
     */
    public function getCategory($product)
    {
        $googleCategory = '';
        try {
            $categoryIds = $product->getCategoryIds();
            $categories = $this->categoryCollection->create()
                ->addAttributeToSelect('google_product_category')
                ->addAttributeToFilter('entity_id', $categoryIds)
                ->addIsActiveFilter();

            foreach ($categories as $category) {
                $googleCategory = $category->getData('google_product_category');
                if ($googleCategory != null) {
                    return $googleCategory;
                    break;
                }
            }
        } catch (\Exception $e) {
            $this->logMessage($e->getMessage());
        }
        return $googleCategory;
    }

    /**
     * @param $childProductId
     * @return null|array
     */
    public function getProductParentIds($childProductId = null)
    {
        try {
            // For Configurable Product ids
            if ($this->configurable->getParentIdsByChild($childProductId)) {
                $parentIds = $this->configurable->getParentIdsByChild($childProductId);
                if (sizeof($parentIds) > 0 && !empty($parentIds)) {
                    return $parentIds;
                }
            }

            // For Bundle Product ids
            if ($this->bundle->getParentIdsByChild($childProductId)) {
                $parentIds = $this->bundle->getParentIdsByChild($childProductId);
                if (sizeof($parentIds) > 0 && !empty($parentIds)) {
                    return $parentIds;
                }
            }

            // For Grouped Product ids
            if ($this->grouped->getParentIdsByChild($childProductId)) {
                $parentIds = $this->grouped->getParentIdsByChild($childProductId);
                if (sizeof($parentIds) > 0 && !empty($parentIds)) {
                    return $parentIds;
                }
            }
            return null;
        }catch (\Exception $e){
            $this->logMessage($e->getMessage());
            return null;
        }
    }
    /**
     * @return array
     */
    public function getFacebookAttribute()
    {
        return [
            ['value' => 'id', 'label' => "id"],
            ['value' => 'title', 'label' => "title"],
            ['value' => 'description', 'label' => "description"],
            ['value' => 'condition', 'label' => "condition"],
            ['value' => 'link', 'label' => "link"],
            ['value' => 'image_link', 'label' => "image_link"],
            ['value' => 'brand', 'label' => "brand"],
            ['value' => 'additional_image_link', 'label' => "additional_image_link"],
            ['value' => 'age_group', 'label' => "age_group"],
            ['value' => 'color', 'label' => "color"],
            ['value' => 'gender', 'label' => "gender"],
            ['value' => 'google_product_category', 'label' => "google_product_category"],
            ['value' => 'material', 'label' => "material"],
            ['value' => 'pattern', 'label' => "pattern"],
            ['value' => 'product_type', 'label' => "product_type"],
            ['value' => 'shipping', 'label' => "shipping"],
            ['value' => 'shipping_weight', 'label' => "shipping_weight"],
            ['value' => 'size', 'label' => "size"],
            ['value' => 'inventory', 'label' => "inventory"],
            ['value' => 'custom_option', 'label' => "custom_option"],
        ];
    }

    /**
     * @return array
     */
    public function getProductAttribute()
    {
        try {
            $attributes = [];
            $attributeInfo = $this->productAttributes->create();
            foreach ($attributeInfo as $items) {
                array_push($attributes, ['value' => $items->getData('attribute_code'), 'label' => $items->getData('attribute_code')]);
            }
        }catch (\Exception $e){
            $this->logMessage($e->getMessage());
        }
        return $attributes;
    }

    /**
     * @param \Magento\Catalog\Model\Product $product
     * @param $ProductMediaUrl
     * @param $storeID
     * @return string
     */
    public function getProductAdditionalImageUrl($product, $ProductMediaUrl, $storeID = null)
    {
        try {
            $allImages = [];
            $checkImages = [];
            $addImgUrl = null;
            $productModel = $this->productRepository->getById($product->getId());
            $images = $productModel->getMediaGalleryImages();

            $removePUB = 0;
            if ($this->isRemovePubDir($storeID)) {
                $removePUB = 1;
            }

            foreach ($images as $child) {
                if (isset($child['url']) && $child['url'] !== '') {
                    if ($removePUB) {
                        $imageUrl = str_replace('pub/', '', $child->getUrl());
                        $addImgUrl = $imageUrl;
                        $checkImages[] = $imageUrl;
                    } else {
                        $addImgUrl = $child->getUrl();
                        $checkImages[] = $child->getUrl();
                    }

                    if (strlen(implode(',', $checkImages)) <= 2000) {
                        $allImages[] = $addImgUrl;
                    } else {
                        break;
                    }
                    $addImgUrl = null;
                }
            }

            $key = (int)array_search($ProductMediaUrl, $allImages);
            unset($allImages[$key]);
            $otherImages = implode(',', $allImages);
            return $otherImages;
        } catch (\Exception $e) {
            $this->logMessage($e->getMessage());
        }
        return '';
    }

    /**
     * @param $id
     * @param $sku
     * @return string
     */
    public function getProductAvailableStatus($id, $sku)
    {
        $stock = 'in stock';

        if (version_compare($this->getMagentoVersion->getVersion(), '2.3.0', '<')) {
            try {
                $productStockObj = $this->stockRegistryInterface->getStockItem($id);
                $stockStatus = $productStockObj->getIsInStock();

                if ($stockStatus != null) {
                    if ($stockStatus || !$stock->getData('manage_stock')) {
                        $stock = 'in stock';
                    } else {
                        $stock = 'out of stock';
                    }
                } else {
                    $productStock = $this->stockItemRepository->get($id);
                    if ($productStock->getIsInStock() || !$productStock->getData('manage_stock')) {
                        $stock = 'in stock';
                    } else {
                        $stock = 'out of stock';
                    }
                }
            } catch (\Exception $e) {
                $this->logMessage($e->getMessage());
                return 'in stock';
            }
        } else {
            try {
                $objectManager = ObjectManager::getInstance();
                $result = 0;

                if ($this->moduleManager->isEnabled('Magento_InventorySalesApi') && $this->moduleManager->isEnabled('Magento_InventorySalesAdminUi')) {
                    $stockId = $this->getStockId();
                    if ($this->isProductSalable->execute($sku, $stockId)) {
                        $result = 1;
                    }

                    if ($result == 0) {
                        $getSalableQuantityDataBySku = $objectManager->create('\Magento\InventorySalesAdminUi\Model\GetSalableQuantityDataBySku');
                        $productAvailableQuantity = null;
                        if (isset($getSalableQuantityDataBySku->execute($sku)[0]['qty'])) {
                            $productAvailableQuantity = $getSalableQuantityDataBySku->execute($sku)[0]['qty'];
                        }
                        if ($productAvailableQuantity != null && $productAvailableQuantity > 0) {
                            $stock = 'in stock';
                        } else {
                            $stock = $this->stockRegistryInterface->getStockItem($id);
                            if ($stock->getIsInStock() || !$stock->getData('manage_stock')) {
                                $stock = 'in stock';
                            } else {
                                $stock = 'out of stock';
                            }
                        }
                    }
                } else {
                    $stock = $this->stockRegistryInterface->getStockItem($id);
                    if ($stock->getIsInStock() || !$stock->getData('manage_stock')) {
                        $stock = 'in stock';
                    } else {
                        $stock = 'out of stock';
                    }
                }
            } catch (\Exception $e) {
                $this->logMessage($e->getMessage());
                return 'in stock';
            }
        }
        return $stock;
    }

    /**
     * @return int
     */
    public function getStockId()
    {
        try {
            if ($this->moduleManager->isEnabled('Magento_InventorySalesApi')) {
                $websiteCode = $this->storeManager->getWebsite()->getCode();
                $stockId = $this->stockResolver->execute(\Magento\InventorySalesApi\Api\Data\SalesChannelInterface::TYPE_WEBSITE, $websiteCode)->getStockId();
                return $stockId;
            }
        } catch (\Exception $e) {
            $this->logMessage($e->getMessage());
            return 0;
        }
        return 0;
    }

    /**
     * @param $productId
     * @param $productSku
     * @return mixed |int
     */
    public function getProductQty($productId, $productSku)
    {
        $qty = 0;
        try {
            if ($this->moduleManager->isEnabled('Magento_InventorySalesApi')) {
                $qty = $this->productSalableQty->execute($productSku, $this->getStockId());
            } else {
                $stock = $this->stockRegistryInterface->getStockItem($productId);
                $qty = $stock->getQty();
                if (!$stock->getData('manage_stock') && $qty <= 0){
                    $qty = 10;
                }
            }
        }catch (\Exception $e){
            $this->logMessage($e->getMessage());
            return $qty;
        }
        return $qty;
    }

    /**
     * @param $msg
     */
    public function logMessage($msg)
    {
        $this->_logger->info($msg);
    }

    /**
     * @param $date
     * @return mixed |string
     */
    public function getSpecialPriceDate($date)
    {
        try {
            $format = 'Y-m-d H:i:s';
            $storeDatetime = date($format, strtotime($date));
            return $this->dateTime->date($storeDatetime)->format('c');
        }catch (\Exception $e){
            $this->logMessage($e->getMessage());
        }
        return '';
    }

    /**
     * @param $string
     * @param $limit
     * @return mixed |string
     */
    public function formatText($string, $limit)
    {
        $str = $string;
        try {
            $str = trim($string);
            $str = strip_tags(html_entity_decode($str, ENT_HTML5 | ENT_QUOTES, 'UTF-8'));
            $str = preg_replace("/\s\s+/", " ", str_replace(["\r\n", "\r", "\n", "\t"], " ", $str));
            $str = substr($str, 0, $limit);
            return $str;
        }catch (\Exception $e){
            $this->logMessage($e->getMessage());
        }
        return $str;
    }
}