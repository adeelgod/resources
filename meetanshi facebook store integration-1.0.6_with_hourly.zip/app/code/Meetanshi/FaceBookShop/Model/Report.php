<?php

namespace Meetanshi\FaceBookShop\Model;

use Magento\Framework\Model\AbstractModel;

/**
 * Class Facebookshop
 * @package Meetanshi\FaceBookShop\Model
 */
class Report extends AbstractModel
{
    protected function _construct()
    {
        $this->_init('Meetanshi\FaceBookShop\Model\ResourceModel\Report');
    }
}
