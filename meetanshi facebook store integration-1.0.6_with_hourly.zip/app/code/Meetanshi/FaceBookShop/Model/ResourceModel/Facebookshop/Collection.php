<?php

namespace Meetanshi\FaceBookShop\Model\ResourceModel\Facebookshop;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @package Meetanshi\FaceBookShop\Model\ResourceModel\Facebookshop
 */
class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'id';
    /**
     * @var string
     */
    protected $_eventPrefix = 'facebook_attribute_collection';
    /**
     * @var string
     */
    protected $_eventObject = 'facebook_attribute_collection';

    /**
     *
     */
    protected function _construct()
    {
        $this->_init('Meetanshi\FaceBookShop\Model\Facebookshop', 'Meetanshi\FaceBookShop\Model\ResourceModel\Facebookshop');
    }
}
