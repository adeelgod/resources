<?php

namespace Meetanshi\FaceBookShop\Controller\Adminhtml\Attributes;

use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Meetanshi\FaceBookShop\Model\FacebookshopFactory;

/**
 * Class Addrow
 * @package Meetanshi\FaceBookShop\Controller\Adminhtml\Attributes
 */
class Addrow extends Action
{
    /**
     * @var Registry
     */
    private $coreRegistry;
    /**
     * @var FacebookshopFactory
     */
    private $gridFactory;

    /**
     * Addrow constructor.
     * @param Context $context
     * @param Registry $coreRegistry
     * @param FacebookshopFactory $gridFactory
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        FacebookshopFactory $gridFactory
    )
    {

        parent::__construct($context);
        $this->coreRegistry = $coreRegistry;
        $this->gridFactory = $gridFactory;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|null
     */
    public function execute()
    {
        try {
            $rowId = (int)$this->getRequest()->getParam('id');
            $rowData = $this->gridFactory->create();
            if ($rowId) {
                $rowData = $rowData->load($rowId);
                $rowTitle = $rowData->getTitle();
                if (!$rowData->getId()) {
                    $this->messageManager->addError(__('row data no longer exist.'));
                    $this->_redirect('facebookshop/attribute/index');
                    return null;
                }
            }
            $this->coreRegistry->register('row_data', $rowData);
            $resultPage = $this->resultFactory->create(ResultFactory::TYPE_PAGE);
            $title = $rowId ? __('Edit Attribute Mapping') . $rowTitle : __('Add Attribute Mapping');
            $resultPage->getConfig()->getTitle()->prepend($title);
            return $resultPage;
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Meetanshi_FaceBookShop::facebook_shop');
    }
}
