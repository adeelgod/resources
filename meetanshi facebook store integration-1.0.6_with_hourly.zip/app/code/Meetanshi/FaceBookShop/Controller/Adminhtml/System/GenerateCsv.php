<?php

namespace Meetanshi\FaceBookShop\Controller\Adminhtml\System;

use Magento\Framework\Controller\Result\JsonFactory;
use Meetanshi\FaceBookShop\Helper\Data;
use Magento\Backend\App\Action\Context;
use \Psr\Log\LoggerInterface;
use Magento\Backend\App\Action;

/**
 * Class GenerateCsv
 * @package Meetanshi\FaceBookShop\Controller\Adminhtml\System
 */
class GenerateCsv extends Action
{
    /**
     * @var LoggerInterface
     */
    protected $_logger;
    /**
     * @var JsonFactory
     */
    private $jsonFactory;
    /**
     * @var Data
     */
    private $helper;

    /**
     * GenerateCsv constructor.
     * @param Context $context
     * @param LoggerInterface $logger
     * @param JsonFactory $jsonFactory
     * @param Data $data
     */
    public function __construct(
        Context $context,
        LoggerInterface $logger,
        JsonFactory $jsonFactory,
        Data $data
    )
    {
        $this->_logger = $logger;
        $this->jsonFactory = $jsonFactory;
        $this->helper = $data;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\Result\Json|\Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $res = null;
        if ($this->helper->isStoreSpecific()) {
            $selectedStores = $this->helper->getSelectedStores();
            if ($selectedStores != null) {
                $stores = explode(',', $selectedStores);

                if (sizeof($stores) > 0) {
                    foreach ($stores as $store) {
                        $res = $this->helper->configGenerateCsv('backend', $store);
                    }
                }
            }
        }

        if ($res == null) {
            $res = $this->helper->configGenerateCsv('backend');
        }
        $response = [
            'succeess' => "true",
            'successmesg' => ""
        ];
        $result = $this->jsonFactory->create();
        $result->setData($response);

        if ($res) {
            $this->messageManager->addSuccess(__('Generate CSV Successfully'));
        } else {
            $this->messageManager->addError(__('Unable to create CSV try again later'));
        }
        return $result;
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return true;
    }
}
