<?php

namespace Meetanshi\FaceBookShop\Controller\Adminhtml\Report\File;

use Magento\Backend\App\Action;
use Magento\Framework\App\Response\Http\FileFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\ImportExport\Controller\Adminhtml\Export as ExportController;
use Magento\Framework\Filesystem;

/**
 * Controller that download file by name.
 */
class Download extends ExportController
{
    /**
     * Url to this controller
     */
    const URL = 'facebookshop/report_file/download/';
    /**
     * @var FileFactory
     */
    private $fileFactory;
    /**
     * @var Filesystem
     */
    private $filesystem;

    /**
     * DownloadFile constructor.
     * @param Action\Context $context
     * @param FileFactory $fileFactory
     * @param Filesystem $filesystem
     */
    public function __construct(
        Action\Context $context,
        FileFactory $fileFactory,
        Filesystem $filesystem
    )
    {
        $this->fileFactory = $fileFactory;
        $this->filesystem = $filesystem;
        parent::__construct($context);
    }

    /**
     * Controller basic method implementation.
     *
     * @return \Magento\Framework\App\ResponseInterface
     * @throws LocalizedException
     */
    public function execute()
    {
        $params = $this->getRequest()->getParams();
        if (!isset($params['dir'])) {
            throw new LocalizedException(__('Please provide export file name'));
        }
        /*if (empty($fileName = $this->getRequest()->getParam('filename'))) {
            throw new LocalizedException(__('Please provide export file name'));
        }*/
        try {
            //$fileName = $this->getRequest()->getParam('filename');
            $dir = $this->getRequest()->getParam('dir');
            if (isset($params['filename'])){
                $fileName = $params['filename'];
            }else{
                $fileName = 'FBProductUpload.csv';
            }

            $path = 'media/' . $dir . '/' . $fileName;
            $directory = $this->filesystem->getDirectoryRead(DirectoryList::PUB);
            if ($directory->isFile($path)) {
                return $this->fileFactory->create(
                    $path,
                    $directory->readFile($path),
                    DirectoryList::PUB
                );
            }else{
                $this->messageManager->addErrorMessage(__('Their is no export file with such name %1', $fileName));
                return $this->_redirect($this->_redirect->getRefererUrl());
            }
        } catch (LocalizedException $exception) {
            throw new LocalizedException(__('There are no export file with such name %1', $fileName));
        } catch (\Exception $e){
            throw new LocalizedException(__($e->getMessage()));
        }
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Meetanshi_FaceBookShop::facebook_shop');
    }
}
