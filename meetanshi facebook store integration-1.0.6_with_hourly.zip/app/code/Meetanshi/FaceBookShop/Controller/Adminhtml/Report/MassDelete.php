<?php

namespace Meetanshi\FaceBookShop\Controller\Adminhtml\Report;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Meetanshi\FaceBookShop\Model\Report;
use Meetanshi\FaceBookShop\Model\ResourceModel\Report\CollectionFactory;
use Meetanshi\FaceBookShop\Helper\Data;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\Filesystem;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\App\Filesystem\DirectoryList;

/**
 * Class Delete
 * @package Meetanshi\FaceBookShop\Controller\Adminhtml\Report
 */
class MassDelete extends Action
{
    /**
     * @var Registry
     */
    private $coreRegistry;
    /**
     * @var FacebookshopFactory
     */
    private $gridFactory;
    /**
     * @var Data
     */
    protected $helper;

    /**
     * @var Filter
     */
    protected $filter;

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;
    /**
     * @var File
     */
    protected $file;
    /**
     * @var Filesystem
     */
    protected $fileSystem;

    /**
     * Delete constructor.
     * @param Context $context
     * @param Registry $coreRegistry
     * @param Report $gridFactory
     * @param Data $helper
     * @param Filter $filter
     * @param CollectionFactory $collectionFactory
     * @param Filesystem $fileSystem
     * @param File $file
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        Report $gridFactory,
        Data $helper,
        Filter $filter,
        CollectionFactory $collectionFactory,
        Filesystem $fileSystem,
        File $file
    )
    {
        $this->coreRegistry = $coreRegistry;
        $this->gridFactory = $gridFactory;
        $this->helper = $helper;
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->file = $file;
        $this->fileSystem = $fileSystem;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        try{
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $collectionSize = $collection->count();

            foreach ($collection as $item) {
                $id = $item['id'];
                $row = $this->gridFactory->load($id);
                $row->delete();

                $mediaDirectory = $this->fileSystem->getDirectoryRead(DirectoryList::MEDIA);
                $mediaRootDir = $mediaDirectory->getAbsolutePath();

                if ($this->file->isExists($mediaRootDir . $id . '/'.$item['csv_file']))  {
                    $this->file->deleteFile($mediaRootDir . $id . '/'.$item['csv_file']);
                }
            }
            $this->messageManager->addSuccess(__('A total of %1 Report(s) have been deleted.', $collectionSize));
        }catch (\Exception $e){
            $this->messageManager->addError($e->getMessage());
        }
        $this->_redirect('facebookshop/index/report');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Meetanshi_FaceBookShop::facebook_shop');
    }
}
