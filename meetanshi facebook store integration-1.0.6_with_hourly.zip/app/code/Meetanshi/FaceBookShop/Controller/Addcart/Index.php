<?php

namespace Meetanshi\FaceBookShop\Controller\Addcart;

use Magento\Catalog\Model\ProductFactory;
use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Data\Form\FormKey;
use Magento\Checkout\Model\Cart;
use Magento\Catalog\Model\Product;

/**
 * Class Index
 * @package Meetanshi\FaceBookShop\Controller\Addcart
 */
class Index extends Action
{
    /**
     * @var ProductFactory
     */
    private $productFactory;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
    /**
     * @var FormKey
     */
    private $formKey;
    /**
     * @var Cart
     */
    private $cart;
    /**
     * @var Product
     */
    private $product;

    /**
     * Index constructor.
     * @param Context $context
     * @param StoreManagerInterface $storeManager
     * @param ProductFactory $productFactory
     * @param FormKey $formKey
     * @param Cart $cart
     * @param Product $product
     */
    public function __construct(
        Context $context,
        StoreManagerInterface $storeManager,
        ProductFactory $productFactory,
        FormKey $formKey,
        Cart $cart,
        Product $product
    )
    {
        $this->storeManager = $storeManager;
        $this->productFactory = $productFactory;
        $this->formKey = $formKey;
        $this->cart = $cart;
        $this->product = $product;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     */
    public function execute()
    {
        $url = $this->storeManager->getStore()->getBaseUrl();
        $parentId = null;
        $productId = null;
        $bgProductId = null;
        $storeId = null;
        try {
            $param = $this->getRequest()->getParams();
            if (isset($param['parentid'])) {
                $parentId = $param['parentid'];
            }
            if (isset($param['productid'])) {
                $productId = $param['productid'];
            }
            if (isset($param['bgparentid'])) {
                $bgProductId = $param['bgparentid'];
            }
            if (isset($param['storeid'])) {
                $storeId = $param['storeid'];
            }

            if ($parentId != null) {
                $product = $this->productFactory->create()->load($parentId);
                $childProduct = $this->productFactory->create()->load($productId);

                $product->setStoreId($storeId);
                $url = $product->getProductUrl();
                $params = [];
                $params['product'] = $product->getId();
                $params['qty'] = 1;
                $options = [];

                $productAttributeOptions = $product->getTypeInstance(true)->getConfigurableAttributesAsArray($product);

                foreach ($productAttributeOptions as $option) {
                    $options[$option['attribute_id']] = $childProduct->getData($option['attribute_code']);
                }

                $params['super_attribute'] = $options;
                $this->cart->addProduct($product, $params);
                $this->cart->save();
            } else {
                if ($bgProductId != null){
                    $parent = $this->product->load($bgProductId);
                    $parent->setStoreId($storeId);
                    $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                    $resultRedirect->setUrl($parent->getProductUrl());
                    return $resultRedirect;
                } else {
                    $params = array(
                        'form_key' => $this->formKey->getFormKey(),
                        'product' => $productId,
                        'qty' => 1
                    );
                    $product = $this->product->load($productId);
                    $product->setStoreId($storeId);
                    $url = $product->getProductUrl();
                    $this->cart->addProduct($product, $params);
                    $this->cart->save();
                }
            }
        } catch (\Exception $e) {
            $this->messageManager->addError(__($e->getMessage()));
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setUrl($url);
            return $resultRedirect;
        }
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        $resultRedirect->setPath('checkout/cart');
        return $resultRedirect;
    }
}
