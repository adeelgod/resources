<?php

namespace Meetanshi\FaceBookShop\Cron;

use Meetanshi\FaceBookShop\Helper\Data;

/**
 * Class GenerateCsvHourly
 * @package Meetanshi\FaceBookShop\Cron
 */
class GenerateCsvHourly
{
    /**
     * @var Data
     */
    private $helper;

    /**
     * GenerateCsv constructor.
     * @param Data $helper
     */
    public function __construct(
        Data $helper
    )
    {
        $this->helper = $helper;
    }

    /**
     *
     */
    public function execute()
    {
        if ($this->helper->isEnableSchedule()) {
            $frequency = $this->helper->getFrequency();
            //$time = explode(',', $this->helper->getStartTime());

            $res = 0;
            $stores = [];

            if ($this->helper->isStoreSpecific()) {
                $selectedStores = $this->helper->getSelectedStores();
                if ($selectedStores != null) {
                    $stores = explode(',', $selectedStores);
                    if (sizeof($stores) > 0) {
                        $res = 1;
                    }
                }
            }

            if ($frequency == 'hourly') {
                if ($res){
                    foreach ($stores as $store) {
                        $result = $this->helper->configGenerateCsv('cron', $store);
                        $this->helper->logMessage('Cron Result Csv Store : ' . $store .' '. $result);
                    }
                }else {
                    $result = $this->helper->configGenerateCsv('cron');
                    $this->helper->logMessage('Cron Result Csv : ' . $result);
                }
            }
        }
    }
}
