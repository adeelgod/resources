# m2-module-revolut-whitelabel

Module path: Revolut/Payment

composer name: revolut/module-payment