define([
        'jquery',
        'Magento_Payment/js/view/payment/cc-form',
        'mage/storage',
        'mage/url',
        'Magento_Checkout/js/model/full-screen-loader',
        'ko',
        'Magento_Checkout/js/model/quote',
        'Magento_Customer/js/model/customer',
        'Magento_Checkout/js/action/redirect-on-success',
        'Revolut_Payment/js/revolutlib/revolut'
    ],
    function (
        $,
        Component,
        storage,
        url,
        fullScreenLoader,
        ko,
        quote,
        customer,
        redirectOnSuccessAction
    ) {
        'use strict';

        return Component.extend({
            defaults: {
                template : 'Revolut_Payment/payment/revolut-form',
                mode : window.checkoutConfig.payment.revolut_form.mode,
                showPostCode : window.checkoutConfig.payment.revolut_form.showPostCode,
                revolutCard : ko.observable(null),
                publicId : ko.observable(null),
                revolutOrder : ko.observable(null),
                errorCreateRevolutOrder :ko.observable(null)
            },
            initObservable: function(){
                var self = this;
                this._super();

                return this;
            },

            createRevolutForm: function() {
                var self = this;
                fullScreenLoader.startLoader();
                //target is a HTML DOM Object
                var target = document.getElementById('revolut-card-element');
                storage.post(
                    url.build('rest/V1/create/revolut/order'),
                ).done(function (response) {
                    var data = JSON.parse(response);
                    if (data.success) {
                        var core = self;
                        self.revolutOrder(data.order_data);
                        RevolutCheckout(data.public_id, self.mode).then(function (instance) {
                            self.publicId(data.public_id);
                            var card = instance.createCardField({
                                target: target,
                                hidePostcodeField: self.showPostCode,
                                onSuccess(){
                                    self.handleSuccess(core);
                                },
                                onError(messages) {
                                    self.handleError(messages)
                                },
                                onValidation(messages) {
                                    self.handleValidate(messages)
                                }
                            });
                            self.revolutCard(card)

                            fullScreenLoader.stopLoader();
                        });
                    } else {
                        $('#reolutForm').hide();
                        self.errorCreateRevolutOrder(data.mess)
                        self.messageContainer.addErrorMessage({
                            message: $.mage.__(data.mess)
                        });
                        fullScreenLoader.stopLoader();
                    }

                });
            },

            placeOrder: function (data, event) {
                var self = this;
                var billingAddress = quote.billingAddress();
                var customerData = customer.customerData;

                if (self.errorCreateRevolutOrder()) {
                    self.messageContainer.addErrorMessage({
                        message: $.mage.__(self.errorCreateRevolutOrder())
                    });
                    fullScreenLoader.stopLoader();
                } else {
                    fullScreenLoader.startLoader();
                    self.revolutCard().submit({
                        email: customerData.email ? customerData.email : quote.guestEmail,
                        phone: billingAddress.telephone,
                        name: billingAddress.firstname + ' ' + billingAddress.lastname,
                        billingAddress: {
                            countryCode: billingAddress.countryId,
                            region: billingAddress.region,
                            city: billingAddress.city,
                            streetLine1: billingAddress.street[0],
                            streetLine2: billingAddress.street[1],
                            postcode: billingAddress.postcode
                        }
                    });
                }
            },

            context: function() {
                return this;
            },

            getCode: function() {
                return 'revolut_form';
            },

            isActive: function() {
                return true;
            },

            getData: function() {
                var self = this;
                return {
                    'method': self.getCode(),
                    'additional_data': {
                        'publicId' : self.publicId(),
                        'revolutOrder' : self.revolutOrder()
                    }
                }
            },

            handleError: function(messages) {
                var elementShowError = '#show-error';
                $(elementShowError).hide();
                if (messages) {
                    $(elementShowError).text(messages.message)
                    $(elementShowError).show();
                }
                fullScreenLoader.stopLoader();
            },

            handleSuccess: function(core) {
                core.getPlaceOrderDeferredObject()
                    .fail(
                        function () {
                            fullScreenLoader.stopLoader(true);
                            self.isPlaceOrderActionAllowed(true);
                        }
                    ).done(
                    function () {
                        redirectOnSuccessAction.execute();
                    }
                );
            },

            handleValidate: function(messages) {
                var elementShowError = '#show-error';
                $(elementShowError).hide();
                if (messages.length > 0) {
                    $(elementShowError).text(messages[0].message)
                    $(elementShowError).show();
                    fullScreenLoader.stopLoader();
                }
            }
        });
    }
);
