!function (e, o, t) {
    e[t] = function (n, r) {
        var c = {
            sandbox: "https://sandbox-merchant.revolut.com/embed.js",
            prod: "https://merchant.revolut.com/embed.js",
            dev: "https://merchant.revolut.codes/embed.js"
        };
        var s = {
            then: function (resolve) {
                require([c[r]],
                    function(Revolut){
                        d = o.createElement("script");
                        d.id = "revolut-checkout",
                            d.src = c[r] || c.prod,
                            d.async = !0,
                            o.head.appendChild(d);
                        resolve(Revolut(n));
                });
            }
        };
        return "function" == typeof Promise ? Promise.resolve(s) : s
    }
}(window, document, "RevolutCheckout");
