<?php

namespace Revolut\Payment\Helper;

use Magento\Framework\Logger\Handler\Base;

/**
 * Class Handler
 * @package Revolut\Payment\Helper
 */
class Handler extends Base
{
    /**
     * @var string
     */
    protected $fileName = '/var/log/revolut/debug.log';
    /**
     * @var int
     */
    protected $loggerType = \Monolog\Logger::DEBUG;
}
