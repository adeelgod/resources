<?php

namespace Revolut\Payment\Helper;


use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Revolut\Payment\Model\ConstantValue;
use Revolut\Payment\Model\Source\Mode;

/**
 * Class ConfigHelper
 * @package Revolut\Payment\Helper
 */
class ConfigHelper extends AbstractHelper
{

    const SANDBOX_MODE = 'payment/revolut_required/mode';
    const API_KEY = 'payment/revolut_required/api_key';
    const API_KEY_SANDBOX = 'payment/revolut_required/api_key_sandbox';
    const SHOW_POST_CODE = 'payment/revolut_form/show_post_code';
    const PAYMENT_ACTION = 'payment/revolut_form/payment_action';

    /**
     * @var \Magento\Framework\Encryption\EncryptorInterface
     */
    protected $encryptor;

    /**
     * ConfigHelper constructor.
     * @param \Magento\Framework\Encryption\EncryptorInterface $encryptor
     * @param Context $context
     */
    public function __construct(
        \Magento\Framework\Encryption\EncryptorInterface $encryptor,
        Context $context
    ) {
        $this->encryptor = $encryptor;
        parent::__construct($context);
    }

    /**
     * @return mixed
     */
    public function getMode() {
        return $this->scopeConfig->getValue(
            self::SANDBOX_MODE,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * @return string
     */
    public function getApiKey() {
        if ($this->getMode() == Mode::PRODUCTION_MODE) {
            return $this->encryptor->decrypt($this->scopeConfig->getValue(
                self::API_KEY,
                \Magento\Store\Model\ScopeInterface::SCOPE_STORE
            ));
        }
        return $this->encryptor->decrypt($this->scopeConfig->getValue(
            self::API_KEY_SANDBOX,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        ));
    }

    /**
     * @return string
     */
    public function getApiUrl() {
        if ($this->getMode() == Mode::PRODUCTION_MODE) {
            return ConstantValue::URL_PROD;
        }
        return ConstantValue::URL_SANDBOX;
    }

    /**
     * @param $path
     * @return mixed
     */
    public function getConfigValue($path) {
        return $this->scopeConfig->getValue(
            $path,
            \Magento\Store\Model\ScopeInterface::SCOPE_STORE
        );
    }
}
