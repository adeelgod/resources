<?php

namespace Revolut\Payment\Helper;


use Magento\Framework\App\Helper\Context;
use Revolut\Payment\Model\ConstantValue;

/**
 * Class DataHelper
 * @package Revolut\Payment\Helper
 */
class DataHelper extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Magento\Framework\Module\ModuleListInterface
     */
    protected $moduleList;

    /**
     * @var \Magento\Framework\App\ProductMetadataInterface
     */
    protected $productMetadata;

    /**
     * @var ConfigHelper
     */
    protected $configHelper;

    /**
     * DataHelper constructor.
     * @param Context $context
     * @param \Magento\Framework\Module\ModuleListInterface $moduleList
     * @param \Magento\Framework\App\ProductMetadataInterface $productMetadata
     * @param ConfigHelper $configHelper
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Module\ModuleListInterface $moduleList,
        \Magento\Framework\App\ProductMetadataInterface $productMetadata,
        \Revolut\Payment\Helper\ConfigHelper $configHelper
    ) {
        parent::__construct($context);
        $this->moduleList = $moduleList;
        $this->productMetadata = $productMetadata;
        $this->configHelper = $configHelper;
    }

    /**
     * @param $url
     * @param null $content
     * @param null $requestMethod
     * @return string
     * @throws \Exception
     */
    public function sendRequest($url, $content = null, $requestMethod = 'POST')
    {
        $httpHeaders = new \Zend\Http\Headers();
        $httpHeaders->addHeaders([
            "Authorization" => "Bearer " . $this->configHelper->getApiKey(),
            "User-Agent" => 'Revolut Payment Gateway/' . $this->moduleList->getOne(ConstantValue::MODULE_NAME)['setup_version']
                . ' Magento/' . $this->productMetadata->getVersion()
                . ' PHP/' . PHP_VERSION,
            "Content-Type" => "application/json; charset=utf-8"
        ]);

        $request = new \Zend\Http\Request();
        $request->setHeaders($httpHeaders);
        $request->setContent($content);
        $request->setUri($url);
        $request->setMethod(strtoupper($requestMethod));


        $client = new \Zend\Http\Client();
        $options = [
            'adapter' => 'Zend\Http\Client\Adapter\Curl',
            'curloptions' => [CURLOPT_FOLLOWLOCATION => true],
            'maxredirects' => 0,
            'timeout' => 30
        ];
        $client->setOptions($options);
        try {
            $response = $client->send($request);
            $responseBody = $response->getBody();
            return $responseBody;
        } catch (\Exception $e) {
            throw new \Exception(__($e->getMessage()));
        }
    }
}
