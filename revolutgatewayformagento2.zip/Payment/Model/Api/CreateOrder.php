<?php

namespace Revolut\Payment\Model\Api;


use Revolut\Payment\Api\CreateOrderInterface;
use Revolut\Payment\Model\ConstantValue;
use Revolut\Payment\Helper\ConfigHelper;

/**
 * Class CreateOrder
 * @package Revolut\Payment\Model\Api
 */
class CreateOrder implements CreateOrderInterface
{
    /**
     * @var \Revolut\Payment\Helper\DataHelper
     */
    protected $dataHelper;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;

    /**
     * @var ConfigHelper
     */
    protected $configHelper;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;

    /**
     * CreateOrder constructor.
     * @param \Revolut\Payment\Helper\DataHelper $dataHelper
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @param ConfigHelper $configHelper
     * @param \Magento\Checkout\Model\Session $checkoutSession
     */
    public function __construct(
        \Revolut\Payment\Helper\DataHelper $dataHelper,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Revolut\Payment\Helper\ConfigHelper $configHelper,
        \Magento\Checkout\Model\Session $checkoutSession
    ) {
        $this->dataHelper = $dataHelper;
        $this->jsonHelper = $jsonHelper;
        $this->configHelper = $configHelper;
        $this->checkoutSession = $checkoutSession;
    }

    /**
     * Returns public_id form revolut
     *
     * @api
     * @return string public_id form revolut.
     */
    public function createOrder() {
        try {
            $quote = $this->checkoutSession->getQuote();
            $params = [
                "amount" => round($quote->getGrandTotal() * 100),
                "currency" => $quote->getStoreCurrencyCode(),
                "capture_mode" => $this->configHelper->getConfigValue(ConfigHelper::PAYMENT_ACTION) == ConstantValue::MAGENTO_AUTHORIZE_CAPTURE ?
                    ConstantValue::REVOLUT_AUTHORIZE_CAPTURE : ConstantValue::REVOLUT_AUTHORIZE_ONLY
            ];
            $apiUrl = $this->configHelper->getApiUrl() . ConstantValue::API_VER . '/' . ConstantValue::ENDPOINT_ORDER;
            $orderResponse = $this->dataHelper->sendRequest($apiUrl, $this->jsonHelper->jsonEncode($params));
            $orderData = $this->jsonHelper->jsonDecode($orderResponse);

            //handle create revolut order error
            if (!isset($orderData['public_id'])) {
                return $this->jsonHelper->jsonEncode([
                    'error' => true,
                    'mess' => $orderData['message']
                ]);
            }

            $result = [
                'success' => true,
                'public_id' => $orderData['public_id'],
                'order_data' => $orderResponse
            ];
        } catch (\Exception $e) {
            $result = [
                'error' => true,
                'mess' => $e->getMessage()
            ];
        }

        return $this->jsonHelper->jsonEncode($result);
    }
}
