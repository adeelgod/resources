<?php

namespace Revolut\Payment\Model\Source;


class Mode
{
    const PRODUCTION_MODE = 0;
    const SANDBOX_MODE = 1;
    public function toOptionArray()
    {
        return [
            [
                'value' => self::SANDBOX_MODE,
                'label' => __('Sandbox')
            ],
            [
                'value' => self::PRODUCTION_MODE,
                'label' => __('Live'),
            ]
        ];
    }
}
