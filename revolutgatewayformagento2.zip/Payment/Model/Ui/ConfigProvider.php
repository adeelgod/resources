<?php

namespace Revolut\Payment\Model\Ui;


use Magento\Checkout\Model\ConfigProviderInterface;
use Revolut\Payment\Model\RevolutForm;
use Revolut\Payment\Model\ConstantValue;
use Revolut\Payment\Helper\ConfigHelper;
use Revolut\Payment\Model\Source\Mode;

/**
 * Class ConfigProvider
 * @package Revolut\Payment\Model\Ui
 */
class ConfigProvider implements ConfigProviderInterface
{
    /**
     *
     */
    const CODE = RevolutForm::CODE;

    /**
     * @var ConfigHelper
     */
    protected $configHelper;

    /**
     * ConfigProvider constructor.
     * @param ConfigHelper $configHelper
     */
    public function __construct(
        ConfigHelper $configHelper
    ) {
        $this->configHelper = $configHelper;
    }

    /**
     * @return array|\array[][]
     */
    public function getConfig()
    {
        return [
            'payment' => [
                self::CODE => [
                    'mode' => $this->configHelper->getMode() == Mode::PRODUCTION_MODE ? ConstantValue::PROD_MODE : ConstantValue::SANDBOX_MODE,
                    'showPostCode' => $this->configHelper->getConfigValue(ConfigHelper::SHOW_POST_CODE) ? true : false
                ]
            ]
        ];
    }
}
