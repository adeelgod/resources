<?php

namespace Revolut\Payment\Block\Adminhtml\System\Config;


use Magento\Framework\View\Element\Template;

class SimplePathAdmin extends \Magento\Framework\View\Element\Template
{
    protected $moduleList;

    public function __construct(
        \Magento\Framework\Module\ModuleListInterface $moduleList,
        Template\Context $context, array $data = []
    ) {
        $this->moduleList = $moduleList;
        parent::__construct($context, $data);
    }

    public function getDownloadDebugUrl()
    {
        return $this->getUrl('revolut/config/downloadDebug', ['version' => $this->getVersion()]);
    }

    public function getVersion()
    {
        return $this->moduleList
            ->getOne('Revolut_Payment')['setup_version'];
    }
}
