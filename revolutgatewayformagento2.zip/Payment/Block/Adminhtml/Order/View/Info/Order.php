<?php

namespace Revolut\Payment\Block\Adminhtml\Order\View\Info;


use Magento\Backend\Block\Template;

/**
 * Class Order
 * @package Revolut\Payment\Block\Adminhtml\Order\View\Info
 */
class Order extends Template
{
    /**
     * @var \Magento\Framework\Registry
     */
    protected $registry;

    /**
     * @var \Revolut\Payment\Model\RevolutOrderFactory
     */
    protected $revolutOrderFactory;

    /**
     * @var \Revolut\Payment\Model\ResourceModel\RevolutOrder
     */
    protected $reRevolutOrderResourceModel;

    /**
     * Order constructor.
     * @param Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Revolut\Payment\Model\RevolutOrderFactory $revolutOrderFactory
     * @param \Revolut\Payment\Model\ResourceModel\RevolutOrder $reRevolutOrderResourceModel
     * @param array $data
     */
    public function __construct(
        Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Revolut\Payment\Model\RevolutOrderFactory $revolutOrderFactory,
        \Revolut\Payment\Model\ResourceModel\RevolutOrder $reRevolutOrderResourceModel,
        array $data = []
    ) {
        $this->registry = $registry;
        $this->revolutOrderFactory = $revolutOrderFactory;
        $this->reRevolutOrderResourceModel = $reRevolutOrderResourceModel;
        parent::__construct($context, $data);
    }

    /**
     * @return array|mixed|null
     */
    public function getOrderPublicId() {
        $order = $this->registry->registry('current_order');
        $incrementId = $order->getIncrementId();
        $revolutOrderModel = $this->revolutOrderFactory->create();
        $this->reRevolutOrderResourceModel->load($revolutOrderModel, $incrementId, 'increment_order_id');
        return $revolutOrderModel->getData('public_id');
    }
}
