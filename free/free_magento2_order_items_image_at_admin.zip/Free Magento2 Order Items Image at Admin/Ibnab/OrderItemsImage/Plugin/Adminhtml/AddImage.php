<?php

namespace Ibnab\OrderItemsImage\Plugin\Adminhtml;
class AddImage {

    /**
     * @param ContextInterface $context
     * @param Url $urlBuilder
     */
    public function __construct(
    ) {
    }

    public function afterGetColumns($items, $result) {

        if (is_array($result)) {
            $newResult['image'] = 'Image';
            foreach($result as $key=>$value){
              $newResult[$key]  = $value;
            }
            $result = $newResult;
        }

        return $result;
    }

}
