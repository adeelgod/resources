<?php

namespace Ibnab\OrderItemsImage\Plugin\Adminhtml;

use Magento\Framework\View\Element\UiComponent\ContextInterface;

class AddRenderer {
    /*
     * @var UrlInterface
     */

    protected $backendHelper;
    protected $_imageHelper;
    protected $_coreRegistry = null;

    /**
     * @param ContextInterface $context
     * @param Url $urlBuilder
     */
    public function __construct(
    \Magento\Backend\Helper\Data $backendHelper, \Magento\Framework\Registry $registry, \Ibnab\OrderItemsImage\Helper\Image $imageHelper
    ) {
        $this->backendHelper = $backendHelper;
        $this->_coreRegistry = $registry;
        $this->_imageHelper = $imageHelper;
    }

    public function afterGetColumns($defaultRenderer, $result) {

        if (is_array($result)) {
            $newResult['image'] = 'col-image';
            foreach ($result as $key => $value) {
                $newResult[$key] = $value;
            }
            $result = $newResult;
        }
        return $result;
    }

    public function beforeGetColumnHtml($defaultRenderer, \Magento\Framework\DataObject $item, $column, $field = null) {
        $html = '';
        switch ($column) {
            case 'image':
                $this->_coreRegistry->register('is_image_renderer', 1);
                $this->_coreRegistry->register('ibnab_current_order_item', $item);
                break;
        }
        return [$item, $column, $field];
    }

    public function afterGetColumnHtml($defaultRenderer, $result) {
        $is_image = $this->_coreRegistry->registry('is_image_renderer');
        $currentItem = $this->_coreRegistry->registry('ibnab_current_order_item');
        $this->_coreRegistry->unregister('is_image_renderer');
        $this->_coreRegistry->unregister('ibnab_current_order_item');
        if ($is_image == 1) {
            return  $this->renderImage($currentItem->getProduct());
        }
        return $result;
    }

    protected function renderImage($product) {
        $this->_imageHelper->addGallery($product);
        $images = $this->_imageHelper->getGalleryImages($product);
        foreach ($images as $image) {
            $item = $image->getData();
            if (isset($item['media_type']) && $item['media_type'] == 'image') {
            $imgPath = isset($item['small_image_url']) ? $item['small_image_url'] : null;    
            return "<a href='".$this->backendHelper->getUrl('catalog/product/edit',['id' => $product->getId()])."' target='_blank'><img src=".$imgPath." alt=".$product->getName()."></a>";
            }
        }
        return null;
    }

}
