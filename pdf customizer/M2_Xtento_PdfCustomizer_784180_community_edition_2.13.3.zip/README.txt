Please visit our support wiki at http://support.xtento.com for installation guides and extension manuals.

If you have any questions regarding this module, please don't hesitate to contact us at info@xtento.com.