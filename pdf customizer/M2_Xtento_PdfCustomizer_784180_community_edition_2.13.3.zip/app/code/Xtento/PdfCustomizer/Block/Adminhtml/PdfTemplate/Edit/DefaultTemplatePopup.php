<?php

/**
 * Product:       Xtento_PdfCustomizer
 * ID:            JbKFcovWrLbTlFqeiEbUALxFYbQI/l6cHxhvVKZ5hc8=
 * Last Modified: 2019-02-05T17:13:45+00:00
 * File:          app/code/Xtento/PdfCustomizer/Block/Adminhtml/PdfTemplate/Edit/DefaultTemplatePopup.php
 * Copyright:     Copyright (c) XTENTO GmbH & Co. KG <info@xtento.com> / All rights reserved.
 */

namespace Xtento\PdfCustomizer\Block\Adminhtml\PdfTemplate\Edit;

use Magento\Backend\Block\Template;

class DefaultTemplatePopup extends Template
{
}
