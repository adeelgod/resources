# AdyenGraphQL extension for ScandiPWA

## Steps to install:

1. Clone this repository into your Magento 2 `app/code` directory
2. Reference this extension from your theme's `scandipwa.json` as `"AdyenGraphQL": "app/code/adyen-graph-ql"`
3. Compile the theme.