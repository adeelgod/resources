/**
 * @category  ScandiPWA
 * @package   ScandiPWA_GraphQl
 * @author    Deniss Dubinins <denissd@scandiweb.com>
 * @copyright Copyright (c) 2020 Scandiweb, Inc (https://scandiweb.com)
 * @license   http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0 (OSL-3.0)
 */

import Adyen from '../component/Adyen';

export const ADYEN_CC = 'adyen_cc';

export class CheckoutPaymentsPlugin {
    aroundPaymentRenderMap = originalMember => ({
        ...originalMember,
        [ADYEN_CC]: this.renderAdyen.bind(this)
    });

    renderAdyen(props) {
        const {
            paymentMethodConfig: config = {},
            setPaymentMethodData
        } = props;

        return (
            <Adyen
              config={ config }
              setPaymentMethodData={ setPaymentMethodData }
            />
        );
    }

    // eslint-disable-next-line no-unused-vars
    aroundRenderSelectedPayment = (args, callback = () => {}, instance) => {
        const { selectedPaymentCode } = instance.props;
        const render = instance.paymentRenderMap[selectedPaymentCode];

        if (!render) {
            return null;
        }

        return render(instance.props);
    };

    // eslint-disable-next-line no-unused-vars
    aroundRenderPayment = (args, callback = () => {}, instance) => {
        const {
            isAdyenLoaded
        } = instance.props;

        const method = args[0];
        const { code } = method;

        if (code === ADYEN_CC && !isAdyenLoaded) {
            return;
        }

        // eslint-disable-next-line consistent-return
        return (
            callback(...args)
        );
    };
}

const {
    aroundPaymentRenderMap,
    aroundRenderPayment,
    aroundRenderSelectedPayment
} = new CheckoutPaymentsPlugin();

export const config = {
    'Component/CheckoutPayments/Component': {
        'member-property': {
            paymentRenderMap: aroundPaymentRenderMap
        },
        'member-function': {
            renderSelectedPayment: aroundRenderSelectedPayment,
            renderPayment: aroundRenderPayment
        }
    }
};

export default config;
