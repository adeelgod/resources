module.exports = [
    './app/plugin/CheckoutContainer.plugin.js',
    './app/plugin/CheckoutBillingContainer.plugin.js',
    './app/plugin/CheckoutPayments.plugin.js',
    './app/plugin/CheckoutPaymentsContainer.plugin.js'
];
