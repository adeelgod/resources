/**
 * @category  ScandiPWA
 * @package   ScandiPWA_GraphQl
 * @author    Deniss Dubinins <denissd@scandiweb.com>
 * @copyright Copyright (c) 2020 Scandiweb, Inc (https://scandiweb.com)
 * @license   http://opensource.org/licenses/OSL-3.0 The Open Software License 3.0 (OSL-3.0)
 */

import { createRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { showNotification } from 'Store/Notification';
import { CheckoutDispatcher, updateCheckoutStatus } from 'Store/Checkout';
import ThreeDS2Popup from './ThreeDS2Popup.component';

/** @namespace ScandiPWA/AdyenGraphQl/Component/ThreeDS2Popup/Container/mapStateToProps */
export const mapStateToProps = state => ({
    threeDS2: state.CheckoutReducer.threeDS2,
    challengeType: state.CheckoutReducer.challengeType,
    challengeToken: state.CheckoutReducer.challengeToken
});

/** @namespace ScandiPWA/AdyenGraphQl/Component/ThreeDS2Popup/Container/mapDispatchToProps */
export const mapDispatchToProps = dispatch => ({
    processThreeDS2: payload => CheckoutDispatcher.processThreeDS2(dispatch, payload),
    showErrorNotification: message => dispatch(showNotification('error', message)),
    setLoading: isLoading => dispatch(updateCheckoutStatus({ isLoading }))
});

export const IDENTIFY_SHOPPER = 'IdentifyShopper';
export const CHALLENGE_SHOPPER = 'ChallengeShopper';

/** @namespace ScandiPWA/AdyenGraphQl/Component/ThreeDS2Popup/Container */
export class ThreeDS2PopupContainer extends PureComponent {
    static propTypes = {
        threeDS2: PropTypes.bool.isRequired,
        challengeType: PropTypes.string.isRequired,
        challengeToken: PropTypes.string.isRequired,
        processThreeDS2: PropTypes.func.isRequired,
        showErrorNotification: PropTypes.func.isRequired,
        setLoading: PropTypes.func.isRequired
    };

    popupRef = createRef();

    state = {
        isLoading: false
    };

    componentDidUpdate(prevProps) {
        const { challengeType: prevChallengeType } = prevProps;
        const { challengeType } = this.props;

        if (challengeType !== prevChallengeType) {
            this.setLoading(false, this.handleThreeDS2);
        }
    }

    containerProps = () => ({
        popupRef: this.popupRef
    });

    setLoading = (isLoading, callback) => {
        const { setLoading } = this.props;

        setLoading(isLoading);
        this.setState({ isLoading }, callback);
    };

    handleThreeDS2 = () => {
        const {
            challengeType,
            challengeToken,
            processThreeDS2,
            showErrorNotification
        } = this.props;
        const { current } = this.popupRef;
        const { adyen } = window;

        if (challengeType === IDENTIFY_SHOPPER) {
            const threeDS2IdentifyComponent = adyen.create('threeDS2DeviceFingerprint', {
                fingerprintToken: challengeToken,
                onComplete: ({ data }) => {
                    this.setLoading(true);
                    threeDS2IdentifyComponent.unmount();
                    processThreeDS2(data);
                },
                onError: showErrorNotification
            }).mount(current);
        }

        if (challengeType === CHALLENGE_SHOPPER) {
            const threeDS2ChallengeShopper = adyen.create('threeDS2Challenge', {
                challengeToken,
                size: '05',
                onComplete: ({ data }) => {
                    this.setLoading(true);
                    threeDS2ChallengeShopper.unmount();
                    processThreeDS2(data);
                },
                onError: showErrorNotification
            }).mount(current);
        }
    };

    render() {
        const { isLoading } = this.state;
        const { threeDS2 } = this.props;

        if (!threeDS2 || isLoading) {
            return null;
        }

        return (
            <ThreeDS2Popup
              { ...this.props }
              { ...this.containerProps() }
            />
        );
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(
    ThreeDS2PopupContainer
);
