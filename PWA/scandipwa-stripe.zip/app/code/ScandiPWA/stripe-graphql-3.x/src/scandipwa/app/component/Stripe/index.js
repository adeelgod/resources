export { default } from './Stripe.container';
