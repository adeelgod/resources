export { default } from './StripeOneClickPayment.container';
