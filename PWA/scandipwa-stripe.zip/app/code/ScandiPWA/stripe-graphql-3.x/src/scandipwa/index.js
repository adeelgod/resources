module.exports = [
    "./app/plugin/Checkout.plugin.js",
    "./app/plugin/CheckoutBilling.plugin.js",
    "./app/plugin/CheckoutBillingContainer.plugin.js",
    "./app/plugin/CheckoutContainer.plugin.js",
    "./app/plugin/CheckoutPayments.plugin.js",
    "./app/plugin/CheckoutPaymentsContainer.plugin.js",
    "./sw/plugin/UrlHandler.plugin.js"
];
