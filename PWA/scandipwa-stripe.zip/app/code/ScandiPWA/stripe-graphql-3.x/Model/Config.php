<?php

namespace ScandiPWA\StripeGraphQl\Model;

class Config
{

    /**
     * Stripe defaultt payment method
     */
    const METHOD_STRIPE = 'stripe_payments';
}
