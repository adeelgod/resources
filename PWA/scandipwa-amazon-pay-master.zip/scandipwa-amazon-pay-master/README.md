# Scandipwa-amazon-pay

Amazon pay module for scandipwa theme.


