/* eslint-disable import/prefer-default-export */
export const PAYPAL_SCRIPT = 'PAYPAL_SCRIPT';
export const PAYPAL_EXPRESS_CREDIT = 'paypal_express_bml';
export const PAYPAL_EXPRESS = 'paypal_express';
