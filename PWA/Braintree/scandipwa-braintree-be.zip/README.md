# ScandiPWA_BraintreeGrapQl

Braintree payment method Extension for ScandiPWA.

This extension allows to use Braintree payment method in ScandiPWA theme with following features:

1. Default Braintree payment method
2. Braintree 3D Secure Verification
3. Braintree payment method save in vault (requires ScandiPWA_VaultGrapQl extension to use saved payments)
