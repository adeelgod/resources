<?php

namespace Meetanshi\FaceBookShop\Model\Config\Source;

use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;

/**
 * Class FbConditions
 * @package Meetanshi\FaceBookShop\Model\Config\Source
 */
class FbConditions extends AbstractSource
{
    /**
     * @var
     */
    protected $options;

    /**
     * @return array
     */
    public function getAllOptions()
    {
        $this->options = [
            ['label' => 'New', 'value' => 'new'],
            ['label' => 'Used', 'value' => 'used'],
            ['label' => 'Refurbished', 'value' => 'refurbished']
        ];
        return $this->options;
    }
}
