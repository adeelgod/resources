<?php

namespace Meetanshi\FaceBookShop\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

/**
 * Class Facebookshop
 * @package Meetanshi\FaceBookShop\Model\ResourceModel
 */
class Report extends AbstractDb
{
    protected function _construct()
    {
        $this->_init('meetanshi_facebook_feed_report', 'id');
    }
}
