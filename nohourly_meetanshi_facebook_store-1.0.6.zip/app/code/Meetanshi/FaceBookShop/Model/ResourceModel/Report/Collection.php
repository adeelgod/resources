<?php

namespace Meetanshi\FaceBookShop\Model\ResourceModel\Report;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @package Meetanshi\FaceBookShop\Model\ResourceModel\Report
 */
class Collection extends AbstractCollection
{
    /**
     * @var string
     */
    protected $_idFieldName = 'id';
    /**
     * @var string
     */
    protected $_eventPrefix = 'facebook_report_collection';
    /**
     * @var string
     */
    protected $_eventObject = 'facebook_report_collection';

    protected function _construct()
    {
        $this->_init('Meetanshi\FaceBookShop\Model\Report', 'Meetanshi\FaceBookShop\Model\ResourceModel\Report');
    }
}
