<?php

namespace Meetanshi\FaceBookShop\Cron;

use Meetanshi\FaceBookShop\Helper\Data;

/**
 * Class GenerateCsv
 * @package Meetanshi\FaceBookShop\Cron
 */
class GenerateCsv
{
    /**
     * @var Data
     */
    private $helper;

    /**
     * GenerateCsv constructor.
     * @param Data $helper
     */
    public function __construct(
        Data $helper
    )
    {
        $this->helper = $helper;
    }

    /**
     *
     */
    public function execute()
    {
        if ($this->helper->isEnableSchedule()) {
            $frequency = $this->helper->getFrequency();
            $time = explode(',', $this->helper->getStartTime());

            $hours = $time[0];
            $minutes = $time[1];
            $seconds = $time[2];

            $res = 0;
            $stores = [];

            if ($this->helper->isStoreSpecific()) {
                $selectedStores = $this->helper->getSelectedStores();
                if ($selectedStores != null) {
                    $stores = explode(',', $selectedStores);
                    if (sizeof($stores) > 0) {
                        $res = 1;
                    }
                }
            }

            if ($frequency == 'daily') {
                if (date("Hi") == "$hours$minutes") {
                    if ($res){
                        foreach ($stores as $store) {
                            $result = $this->helper->configGenerateCsv('cron', $store);
                            $this->helper->logMessage('Cron Result Csv Store : ' . $store .' '. $result);
                        }
                    }else {
                        $result = $this->helper->configGenerateCsv('cron');
                        $this->helper->logMessage('Cron Result Csv : ' . $result);
                    }
                }
            } elseif ($frequency == 'weekly') {
                $weekDay = date('w', strtotime(date("Y/m/d")));
                if (($weekDay == 0 || $weekDay == 6)) {
                    if (date("Hi") == "$hours$minutes") {
                        if ($res){
                            foreach ($stores as $store) {
                                $result = $this->helper->configGenerateCsv('cron', $store);
                                $this->helper->logMessage('Cron Result Csv Store : ' . $store .' '. $result);
                            }
                        }else {
                            $result = $this->helper->configGenerateCsv('cron');
                            $this->helper->logMessage('Cron Result Csv : ' . $result);
                        }
                    }
                }
            } elseif ($frequency == 'monthly') {
                $first = date("Y-m-d", strtotime("first day of this month"));
                $current = date("Y-m-d");

                $diff = date_diff(date_create($first), date_create($current));
                $day = $diff->format("%a");

                if ($day == 0) {
                    if (date("Hi") == "$hours$minutes") {
                        if ($res){
                            foreach ($stores as $store) {
                                $result = $this->helper->configGenerateCsv('cron', $store);
                                $this->helper->logMessage('Cron Result Csv Store : ' . $store .' '. $result);
                            }
                        }else {
                            $result = $this->helper->configGenerateCsv('cron');
                            $this->helper->logMessage('Cron Result Csv : ' . $result);
                        }
                    }
                }
            }
        }
    }
}
