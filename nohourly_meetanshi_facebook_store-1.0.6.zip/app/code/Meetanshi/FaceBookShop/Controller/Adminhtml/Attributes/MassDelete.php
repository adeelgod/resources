<?php

namespace Meetanshi\FaceBookShop\Controller\Adminhtml\Attributes;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Meetanshi\FaceBookShop\Model\Facebookshop;
use Meetanshi\FaceBookShop\Model\ResourceModel\Facebookshop\CollectionFactory;
use Meetanshi\FaceBookShop\Helper\Data;
use Magento\Ui\Component\MassAction\Filter;

/**
 * Class Delete
 * @package Meetanshi\FaceBookShop\Controller\Adminhtml\Attributes
 */
class MassDelete extends Action
{
    /**
     * @var Registry
     */
    private $coreRegistry;
    /**
     * @var FacebookshopFactory
     */
    private $gridFactory;
    /**
     * @var Data
     */
    protected $helper;

    /**
     * @var Filter
     */
    protected $filter;

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * Delete constructor.
     * @param Context $context
     * @param Registry $coreRegistry
     * @param Facebookshop $gridFactory
     * @param Data $helper
     * @param Filter $filter
     * @param CollectionFactory $collectionFactory
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        Facebookshop $gridFactory,
        Data $helper,
        Filter $filter,
        CollectionFactory $collectionFactory
    )
    {
        $this->coreRegistry = $coreRegistry;
        $this->gridFactory = $gridFactory;
        $this->helper = $helper;
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        try {
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $collectionSize = $collection->count();

            foreach ($collection as $item) {
                $id = $item['id'];
                $row = $this->gridFactory->load($id);
                $row->delete();
            }
            $this->messageManager->addSuccess(__('A total of %1 Attribute(s) have been deleted.', $collectionSize));
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        $this->_redirect('facebookshop/attributes/index');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Meetanshi_FaceBookShop::facebook_shop');
    }
}
