<?php

namespace Meetanshi\FaceBookShop\Controller\Adminhtml\Attributes;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Meetanshi\FaceBookShop\Model\FacebookshopFactory;

/**
 * Class Save
 * @package Meetanshi\FaceBookShop\Controller\Adminhtml\Attributes
 */
class Save extends Action
{
    /**
     * @var FacebookshopFactory
     */
    protected $gridFactory;
    /**
     * @var
     */
    protected $datetime;

    /**
     * Save constructor.
     * @param Context $context
     * @param FacebookshopFactory $gridFactory
     */
    public function __construct(
        Context $context,
        FacebookshopFactory $gridFactory
    ) {
        parent::__construct($context);
        $this->gridFactory = $gridFactory;
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('facebookshop/attributes/addrow');
            return;
        }
        try {
            $rowData = $this->gridFactory->create();
            if (isset($data['custom_option']) && $data['custom_option'] != null) {
                $rowData->setFacebookAttributeCode($data['custom_option']);
                $rowData->setMagentoAttributeCode($data['magento_attribute_code']);
            }else{
                $rowData->setData($data);
            }
            if (isset($data['id'])) {
                $rowData->setId($data['id']);
            }
            $rowData->save();
            $this->messageManager->addSuccess(__('Attribute has been successfully saved.'));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage($e->getMessage());
        }
        $this->_redirect('facebookshop/attributes/index');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Meetanshi_FaceBookShop::facebook_shop');
    }
}
