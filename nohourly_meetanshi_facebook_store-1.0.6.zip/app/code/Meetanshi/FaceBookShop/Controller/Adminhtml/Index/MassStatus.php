<?php

namespace Meetanshi\FaceBookShop\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Catalog\Model\Product\Action as ProductAction;
use Magento\Store\Model\StoreManagerInterface;

/**
 * Class MassStatus
 * @package Meetanshi\FaceBookShop\Controller\Adminhtml\Index
 */
class MassStatus extends Action
{
    /**
     * @var
     */
    protected $messageManager;
    /**
     * @var Filter
     */
    private $filter;
    /**
     * @var CollectionFactory
     */
    private $productCollection;
    /**
     * @var ProductAction
     */
    private $productAction;
    /**
     * @var StoreManagerInterface
     */
    private $storeManager;

    /**
     * MassStatus constructor.
     * @param Context $context
     * @param Filter $filter
     * @param CollectionFactory $collection
     * @param ProductAction $action
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $collection,
        ProductAction $action,
        StoreManagerInterface $storeManager
    )
    {
        $this->filter = $filter;
        $this->productCollection = $collection;
        $this->productAction = $action;
        $this->storeManager = $storeManager;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\App\ResponseInterface|\Magento\Framework\Controller\ResultInterface|void
     */
    public function execute()
    {
        try {
            $status = (int)$this->getRequest()->getParam('fb_status');
            $collection = $this->filter->getCollection($this->productCollection->create());
            $collectionSize = $collection->count();
            $storeId = $this->storeManager->getStore()->getId();
            $ids = [];
            $i = 0;
            foreach ($collection as $item) {
                $ids[$i] = $item->getEntityId();
                $i++;
            }
            $this->productAction->updateAttributes($ids, array('enable_fb_product' => $status), $storeId);
            $this->messageManager->addSuccess(__('A total of %1 product(s) facebook status have been changed.', $collectionSize));
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
        }
        $this->_redirect('catalog/product/index');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Meetanshi_FaceBookShop::facebook_shop');
    }
}
