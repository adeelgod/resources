<?php

namespace Meetanshi\FaceBookShop\Block\Adminhtml\Facebookshop;

use Magento\Backend\Block\Widget\Form\Container;
use Magento\Backend\Block\Widget\Context;
use Magento\Framework\Registry;

/**
 * Class Addrow
 * @package Meetanshi\FaceBookShop\Block\Adminhtml\Facebookshop
 */
class Addrow extends Container
{
    /**
     * @var Registry|null
     */
    protected $coreRegistry = null;

    /**
     * Addrow constructor.
     * @param Context $context
     * @param Registry $registry
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        array $data = []
    )
    {
        $this->coreRegistry = $registry;
        parent::__construct($context, $data);
    }

    /**
     *
     */
    protected function _construct()
    {
        try {
            $this->_objectId = 'row_id';
            $this->_blockGroup = 'Meetanshi_FaceBookShop';
            $this->_controller = 'adminhtml_facebookshop';
            $id = $this->getRequest()->getParam('id');
            parent::_construct();
            $url = $this->getUrl('facebookshop/attribute/delete', ['id' => $id]);
            if ($this->_isAllowedAction('Meetanshi_FaceBookShop::facebook_shop')) {
                $this->buttonList->update('save', 'label', __('Save'));
            } else {
                $this->buttonList->remove('save');
            }
            if (!empty($id)) {
                $this->buttonList->add(
                    'delete',
                    [
                        'label' => __('Delete'),
                        'class' => 'save',
                        'onclick' => 'setLocation(\'' . $url . '\')'
                    ],
                    -100
                );
            }
            $this->buttonList->remove('reset');
        } catch (\Exception $e) {
        }
    }

    /**
     * @return \Magento\Framework\Phrase|string
     */
    public function getHeaderText()
    {
        return __('Add Attribute');
    }

    /**
     * @param $resourceId
     * @return bool
     */
    protected function _isAllowedAction($resourceId)
    {
        return $this->_authorization->isAllowed($resourceId);
    }

    /**
     * @return mixed|string
     */
    public function getFormActionUrl()
    {
        if ($this->hasFormActionUrl()) {
            return $this->getData('form_action_url');
        }
        return $this->getUrl('facebookshop/attributes/save');
    }
}
