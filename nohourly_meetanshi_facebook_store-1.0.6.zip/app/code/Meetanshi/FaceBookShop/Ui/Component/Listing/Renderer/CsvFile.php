<?php

namespace Meetanshi\FaceBookShop\Ui\Component\Listing\Renderer;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\UrlInterface;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\App\Filesystem\DirectoryList;
use Meetanshi\FaceBookShop\Controller\Adminhtml\Report\File\Download;

/**
 * Class Actions
 * @package Meetanshi\FaceBookShop\Ui\Component\Listing\Grid\Column
 */
class CsvFile extends Column
{
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var File
     */
    protected $fileDriver;
    /**
     * @var DirectoryList
     */
    protected $directoryList;
    /**
     * @var UrlInterface
     */
    private $urlBuilder;

    /**
     * Actions constructor.
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param StoreManagerInterface $storeManager
     * @param File $fileDriver
     * @param DirectoryList $directoryList
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        StoreManagerInterface $storeManager,
        File $fileDriver,
        DirectoryList $directoryList,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    )
    {
        $this->storeManager = $storeManager;
        $this->fileDriver = $fileDriver;
        $this->directoryList = $directoryList;
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            foreach ($dataSource['data']['items'] as &$item) {
                $name = $this->getData('name');
                if (isset($item['id']) && $item['status'] == 'success') {
                    $dirUrl = $this->directoryList->getPath('pub').'/media/'.$item['id'].'/'.$item['csv_file'];
                    if ($this->fileDriver->isExists($dirUrl)) {
                        $item[$name]['view'] = [
                            'href' => $this->urlBuilder->getUrl(Download::URL, ['filename' => $item['csv_file'], "dir" => $item['id']]),
                            'label' => __('Download')
                        ];
                    }else{
                        $item[$name]['view'] = [
                            'href' => 'javascript:void(0)',
                            'label' => __('File not exist')
                        ];
                    }
                }
            }
        }
        return $dataSource;
    }
}
