<?php
namespace Meetanshi\FaceBookShop\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\App\ObjectManager;

/**
 * Class InstallSchema
 * @package Meetanshi\FaceBookShop\Setup
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @throws \Zend_Db_Exception
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        $table = $installer->getConnection()
            ->newTable($installer->getTable('meetanshi_facebook_attribute'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'nullable' => false, 'primary' => true, 'unsigned' => true],
                'ID'
            )
            ->addColumn(
                'facebook_attribute_code',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false, 'unique' => true],
                'Facebook Attribute Code'
            )
            ->addColumn(
                'magento_attribute_code',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Magento Attribute Code'
            );
            $installer->getConnection()->createTable($table);

        $table1 = $installer->getConnection()
            ->newTable($installer->getTable('meetanshi_facebook_feed_report'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'nullable' => false, 'primary' => true, 'unsigned' => true],
                'ID'
            )
            ->addColumn(
                'started_at',
                Table::TYPE_TIMESTAMP,
                null,
                ['nullable' => false],
                'Started At'
            )
            ->addColumn(
                'finished_at',
                Table::TYPE_TIMESTAMP,
                null,
                ['nullable' => false],
                'Finished At'
            )
            ->addColumn(
                'triggered_by',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Triggered By'
            )
            ->addColumn(
                'product_ids',
                Table::TYPE_TEXT,
                null,
                ['nullable' => false],
                'Product Ids'
            )
            ->addColumn(
                'status',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Status'
            )
            ->addColumn(
                'message',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Message'
            );

        $installer->getConnection()->createTable($table1);

            $installer->getConnection()->addIndex(
            $installer->getTable('meetanshi_facebook_attribute'),
            $setup->getIdxName(
                $installer->getTable('meetanshi_facebook_attribute'),
                ['facebook_attribute_code','magento_attribute_code'],
                AdapterInterface::INDEX_TYPE_FULLTEXT
            ),
            ['facebook_attribute_code','magento_attribute_code'],
            AdapterInterface::INDEX_TYPE_FULLTEXT
        );

        $installer->getConnection()->addIndex(
            $installer->getTable('meetanshi_facebook_feed_report'),
            $setup->getIdxName(
                $installer->getTable('meetanshi_facebook_feed_report'),
                ['triggered_by','product_ids','status','message'],
                AdapterInterface::INDEX_TYPE_FULLTEXT
            ),
            ['triggered_by','product_ids','status','message'],
            AdapterInterface::INDEX_TYPE_FULLTEXT
        );

        try{
            $installer->getConnection()->query("INSERT INTO `{$installer->getTable('meetanshi_facebook_attribute')}` (`facebook_attribute_code`, `magento_attribute_code`) VALUES
        ('id','sku')");
            $installer->getConnection()->query("INSERT INTO `{$installer->getTable('meetanshi_facebook_attribute')}` (`facebook_attribute_code`, `magento_attribute_code`) VALUES
        ('title', 'name')");
            $installer->getConnection()->query("INSERT INTO `{$installer->getTable('meetanshi_facebook_attribute')}` (`facebook_attribute_code`, `magento_attribute_code`) VALUES
        ('description', 'description')");
            $installer->getConnection()->query("INSERT INTO `{$installer->getTable('meetanshi_facebook_attribute')}` (`facebook_attribute_code`, `magento_attribute_code`) VALUES
        ('image_link', 'image')");
            $installer->getConnection()->query("INSERT INTO `{$installer->getTable('meetanshi_facebook_attribute')}` (`facebook_attribute_code`, `magento_attribute_code`) VALUES
        ('brand', 'country_of_manufacture')");
            $installer->getConnection()->query("INSERT INTO `{$installer->getTable('meetanshi_facebook_attribute')}` (`facebook_attribute_code`, `magento_attribute_code`) VALUES
        ('google_product_category', 'google_product_category')");
        }catch (\Exception $e){
            ObjectManager::getInstance()->get('Psr\Log\LoggerInterface')->info($e->getMessage());
        }
        $installer->endSetup();
    }
}
