<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket Private Sales and Flash Sales v4.x.x
 * @copyright   Copyright (c) 2016 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\PrivateSale\Model;

use Magento\Framework\UrlInterface;
use Magento\Customer\Model\Url as CustomerUrl;
use Magento\Config\Model\ResourceModel\Config;
use Magento\Store\Model\Store;
use Magento\Store\Model\ScopeInterface;
use Magento\Framework\Model\AbstractModel;
use Magento\Framework\Model\Context;
use Magento\Framework\Registry;
use Magento\Framework\Serialize\SerializerInterface;
use Plumrocket\PrivateSale\Helper\Data;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Plumrocket\PrivateSale\Model\Config\Source\SplashPageAccess;
use Plumrocket\PrivateSale\Model\ResourceModel\SplashPageImage\CollectionFactory;
use Plumrocket\PrivateSale\Model\Config\Source\SplashPage as SplashPageOptions;

class Splashpage extends AbstractModel
{
    const CONFIG_PATH = 'prprivatesale/splashpage/data';

    /**
     * Sub directory for media
     *
     * @var string
     */
    const IMAGE_DIR = 'plumrocket/privatesale/splashpage';

    /**
     * Dir for temporary images
     */
    const IMAGE_TMP_DIR = 'plumrocket/privatesale/tmp';

    /**
     * Data
     * @var array
     */
    protected $sData;

    /**
     * Helper
     * @var Data
     */
    protected $helper;

    /**
     * Event
     * @var Event
     */
    protected $event;

    /**
     * @var UrlInterace
     */
    protected $urlBuilder;

    /**
     * @var CustomerUrl
     */
    protected $customerUrl;

    /**
     * @var SerializerInterface
     */
    private $serializer;

    /**
     * @var CurrentDateTime
     */
    private $currentDateTime;

    /**
     * @var CollectionFactory
     */
    private $splashPageImageFactory;

    /**
     * Splashpage constructor.
     *
     * @param Context $context
     * @param Registry $registry
     * @param Data $helper
     * @param CollectionFactory $splashPageImageFactory
     * @param Event $event
     * @param SerializerInterface $serializer
     * @param CurrentDateTime $currentDateTime
     * @param UrlInterface $urlBuilder
     * @param CustomerUrl $customerUrl
     * @param array $data
     */
    public function __construct(
        Context $context,
        Registry $registry,
        Data $helper,
        CollectionFactory $splashPageImageFactory,
        Event $event,
        SerializerInterface $serializer,
        CurrentDateTime $currentDateTime,
        UrlInterface $urlBuilder,
        CustomerUrl $customerUrl,
        array $data = []
    ) {
        $this->helper = $helper;
        $this->event = $event;
        $this->serializer = $serializer;
        $this->currentDateTime = $currentDateTime;
        $this->splashPageImageFactory = $splashPageImageFactory;
        $this->urlBuilder = $urlBuilder;
        $this->customerUrl = $customerUrl;

        parent::__construct($context, $registry, null, null, $data);
    }

    /**
     * @inheritDoc
     */
    protected function _construct()
    {
        parent::_init(Config::class);
    }

    /**
     * @inheritDoc
     */
    public function getData($key = '', $index = null)
    {
        if (empty($this->sData)) {
            $data = $this->helper->getConfig(self::CONFIG_PATH, $this->getStoreId(), $this->getScope());
            $data = ($data == null) ? [] : $this->serializer->unserialize($data);
            $this->setData($data);
            $this->sData = $data;
        }

        return parent::getData($key, $index);
    }

    /**
     * Is enabled redirect to login page
     * @return boolean
     */
    public function isEnabledRedirect()
    {
        return (bool) $this->getData('enabled');
    }

    /**
     * Does must be shown default image
     * @return boolean
     */
    public function showDefaultImage()
    {
        return ! $this->splashPageImageFactory->create()->getSize();
    }

    /**
     * Retrieve images
     * @return array
     */
    public function getActiveImages()
    {
        $currentDate = $this->currentDateTime->getCurrentDate();

        return $this->splashPageImageFactory
            ->create()
            ->addFieldToFilter('exclude', 0)
            ->addFieldToFilter(['active_from', 'active_from'], [['null' => true], ['lt' => $currentDate]])
            ->addFieldToFilter(['active_to', 'active_to'], [['null' => true], ['gt' => $currentDate]])
            ->setOrder('sort_order', 'ASC')
            ->getItems();
    }

    /**
     * @return array
     */
    public function getActiveVideos()
    {
        $videos = (array) $this->getData('videos');
        $currentTimestamp = $this->currentDateTime->getCurrentDate()->getTimestamp();

        foreach ($videos as $key => $video) {
            $activeFromTimestamp = strtotime($video['active_from']);
            $activeToTimestamp = $video['active_to'] ? strtotime($video['active_to']) : null;

            if ($activeFromTimestamp > $currentTimestamp
                || ($activeToTimestamp && $currentTimestamp > $activeToTimestamp)
                || '1' === $video['exclude']
            ) {
                unset($videos[$key]);
            }
        }

        return $videos;
    }

    /**
     * @return array
     */
    public function getImages()
    {
        return $this->splashPageImageFactory->create()->getItems();
    }

    /**
     * @inheritDoc
     */
    public function save()
    {
        $data = is_array($this->getData()) ? $this->serializer->serialize($this->getData()) : $this->getData();
        $this->getResource()->saveConfig(Splashpage::CONFIG_PATH, $data, $this->getScope(), $this->getStoreId());
    }

    /**
     * @return string
     */
    public function getLandingPageUrl()
    {
        switch ($this->getData('landing_page')) {
            case SplashPageOptions::MAGENTO_REGISTRATION_PAGE:
                $url = $this->customerUrl->getRegisterUrl();
                break;
            case SplashPageOptions::MAGENTO_LOGIN_PAGE:
                $url = $this->customerUrl->getLoginUrl();
                break;
            default:
                $url = $this->urlBuilder->getUrl(
                    'prprivatesale/splashpage/login',
                    $this->customerUrl->getLoginUrlParams()
                );
        }

        return $url;
    }

    /**
     * @return bool
     */
    public function isEnabledLaunchingSoon()
    {
        return (int) $this->getData('access') === SplashPageAccess::REGISTER;
    }

    /**
     * @return bool
     */
    public function isEnabledLogin()
    {
        $access = (int) $this->getData('access');
        return SplashPageAccess::LOGIN === $access || SplashPageAccess::LOGIN_AND_REGISTER === $access;
    }

    /**
     * @return bool
     */
    public function isEnabledRegistration()
    {
        $access = (int) $this->getData('access');
        return SplashPageAccess::REGISTER === $access || SplashPageAccess::LOGIN_AND_REGISTER === $access;
    }

    /**
     * @return bool
     */
    public function isUserLoginAndRegistration()
    {
        return (int) $this->getData('access') === SplashPageAccess::LOGIN_AND_REGISTER;
    }

    /**
     * @return string
     */
    private function getScope()
    {
        return isset($this->_data['admin'], $this->_data['store_id'])
            ? ScopeInterface::SCOPE_STORE
            : ScopeConfigInterface::SCOPE_TYPE_DEFAULT;
    }

    /**
     * @return int
     */
    private function getStoreId()
    {
        return isset($this->_data['admin'], $this->_data['store_id'])
            ? (int) $this->_data['store_id']
            : Store::DEFAULT_STORE_ID;
    }
}
