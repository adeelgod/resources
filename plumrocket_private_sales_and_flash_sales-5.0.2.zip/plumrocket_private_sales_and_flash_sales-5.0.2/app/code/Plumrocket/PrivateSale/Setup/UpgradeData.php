<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket Private Sales and Flash Sales v4.x.x
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\PrivateSale\Setup;

use Magento\Cms\Model\BlockFactory;
use Magento\Cms\Model\BlockRepository;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\UpgradeDataInterface;

class UpgradeData implements UpgradeDataInterface
{
    /**
     * @var \Magento\Eav\Setup\EavSetupFactory
     */
    protected $eavSetupFactory;

    /**
     * @var \Magento\Framework\App\State
     */
    protected $state;

    /**
     * @var EventsSetupFactory
     */
    private $eventsSetupFactory;

    /**
     * @var \Plumrocket\PrivateSale\Model\Data\MigrationFactory
     */
    private $migrationDataFactory;

    /**
     * @var BlockFactory
     */
    private $blockFactory;

    /**
     * @var BlockRepository
     */
    private $blockRepository;

    /**
     * UpgradeData constructor.
     * @param EavSetupFactory $eavSetupFactory
     * @param BlockRepository $blockRepository
     * @param BlockFactory $blockFactory
     * @param \Magento\Framework\App\State $state
     * @param EventsSetupFactory $eventsSetupFactory
     * @param \Plumrocket\PrivateSale\Model\Data\MigrationFactory $migrationDataFactory
     */
    public function __construct(
        EavSetupFactory $eavSetupFactory,
        BlockRepository $blockRepository,
        BlockFactory $blockFactory,
        \Magento\Framework\App\State $state,
        \Plumrocket\PrivateSale\Setup\EventsSetupFactory $eventsSetupFactory,
        \Plumrocket\PrivateSale\Model\Data\MigrationFactory $migrationDataFactory
    ) {
        $this->eventsSetupFactory = $eventsSetupFactory;
        $this->migrationDataFactory = $migrationDataFactory;
        $this->eavSetupFactory = $eavSetupFactory;
        $this->blockFactory = $blockFactory;
        $this->blockRepository = $blockRepository;

        try {
            $state->setAreaCode('adminhtml');
        } catch (LocalizedException $e) {
        }
    }

    /**
     * {@inheritdoc}
     * @throws LocalizedException
     */
    public function upgrade(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        /** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        //Version 5.0.0
        if (version_compare($context->getVersion(), '5.0.0', '<=')) {
            $this->eventsSetupFactory->create(['setup' => $setup])->installEntities();

            $allAttributes = [
                \Magento\Catalog\Model\Category::ENTITY => [
                    'privatesale_email_image',
                    'privatesale_date_start',
                    'privatesale_date_end',
                    'privatesale_before_event_start',
                    'privatesale_event_end',
                    'privatesale_private_event',
                    'privatesale_restrict_cgroup',
                    'privatesale_event_landing'
                ],
                \Magento\Catalog\Model\Product::ENTITY  => [
                    'privatesale_date_start',
                    'privatesale_date_end',
                    'privatesale_before_event_start',
                    'privatesale_event_end',
                    'privatesale_private_event',
                    'privatesale_restrict_cgroup',
                    'privatesale_event_landing'
                ]
            ];

            $migrationData = $this->migrationDataFactory->create();
            $migrationData->migrationEventsProcess();

            foreach ($allAttributes as $typeId => $attributeCodes) {
                foreach ($attributeCodes as $attributeCode) {
                    $eavSetup->removeAttribute($typeId, $attributeCode);
                }
            }

            $migrationData->migrationSplashPageProcess();
            $this->createTopBannersBlock();
        }

        $setup->endSetup();
    }

    /**
     * Install CMS Blocks
     */
    private function createTopBannersBlock()
    {
        $blocks = [
            [
                'title' => 'Private Sale Banner №1',
                'identifier' => 'prprivate_sale_banner_1',
                'stores' => [0],
                'is_active' => 1,
                'content' => '<div class="prslide-wrap" style="background-color: #000;">
                    <div class="prslide-content">
                        <div class="prslide-item">
                            <p class="prslide-text">Sale Ends Soon! 20% OFF Everything</p>
                            <a class="prslide-link {{prprivatesale-popup-login-class}}"
                               href="{{prprivatesale-event-url}}"
                               data-form="{{prprivatesale-popup-login-prams}}">SHOP NOW</a>
                        </div>
                    </div>
                 </div>'
            ],
            [
                'title' => 'Private Sale Banner №2',
                'identifier' => 'prprivate_sale_banner_2',
                'stores' => [0],
                'is_active' => 1,
                'content' => '<div class="prslide-wrap prslide-wrap-two" style="background-image: linear-gradient(180deg, #E3F7FD 0%, #D1F1FF 100%);">
                    <div class="prslide-content">
                        <div class="prslide-item">
                            <div class="prslide-description">
                                <img src="{{view url="Plumrocket_PrivateSale::images/topbanners/slide2-image.png"}}" alt="Banner image" width="144" height="37">
                                <p class="prslide-text" style="color: #1c4f9a;">Sport Bags: Last chance to GET 20% OFF all items!</p>
                            </div>
                            <a class="prslide-link {{prprivatesale-popup-login-class}}"
                               href="{{prprivatesale-event-url}}"
                               data-form="{{prprivatesale-popup-login-prams}}">SHOP NOW</a>
                        </div>
                    </div>
                </div>'
            ],
            [
                'title' => 'Private Sale Banner №3',
                'identifier' => 'prprivate_sale_banner_3',
                'stores' => [0],
                'is_active' => 1,
                'content' => '<div class="prslide-wrap prslide-wrap-three" style="background-image: url(\'{{view url="Plumrocket_PrivateSale::images/topbanners/banner3-bg.jpg"}}\');background-repeat:no-repeat;background-size:cover;background-position:center;">
                    <div class="prslide-content">
                        <div class="prslide-item">
                            <p class="prslide-text">Don\'t wait. You\'ll miss out on the sale of the year</p>
                            <a class="prslide-link {{prprivatesale-popup-login-class}}"
                               href="{{prprivatesale-event-url}}"
                               data-form="{{prprivatesale-popup-login-prams}}">SHOP NOW</a>
                        </div>
                    </div>
                </div>'
            ]
        ];

        try {
            foreach ($blocks as $block) {
                $blockData = $this->blockFactory->create(['data' => $block]);
                $this->blockRepository->save($blockData);
            }
        } catch (\Exception $e) {
        }
    }
}
