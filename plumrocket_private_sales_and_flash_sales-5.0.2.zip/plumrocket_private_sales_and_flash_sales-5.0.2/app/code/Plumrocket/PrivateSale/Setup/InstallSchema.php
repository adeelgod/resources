<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket Private Sales and Flash Sales v4.x.x
 * @copyright   Copyright (c) 2016 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\PrivateSale\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @throws \Zend_Db_Exception
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();

        $table = $installer->getConnection()
            ->newTable($installer->getTable('plumrocket_privatesale_preview_access'))
            ->addColumn(
                'code',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Code'
            )
            ->addColumn(
                'active_to',
                Table::TYPE_DATETIME,
                null,
                [],
                'Active To'
            )
            ->setComment('Plumrocket Private Sales Preview Access Codes');
        $installer->getConnection()->createTable($table);

        $table = $installer->getConnection()
            ->newTable($installer->getTable('plumrocket_privatesale_image'))
            ->addColumn(
                'image_id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Image Id'
            )
            ->addColumn(
                'name',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Name of image'
            )
            ->addColumn(
                'active_from',
                Table::TYPE_DATETIME,
                null,
                ['nullable' => true],
                'Active from'
            )
            ->addColumn(
                'active_to',
                Table::TYPE_DATETIME,
                null,
                ['nullable' => true],
                'Active To'
            )
            ->addColumn(
                'sort_order',
                Table::TYPE_SMALLINT,
                null,
                ['default' => 0, 'nullable' => false],
                'Sort order'
            )
            ->addColumn(
                'exclude',
                Table::TYPE_SMALLINT,
                null,
                ['default' => 0, 'nullable' => false],
                'Exclude'
            )
            ->setComment('Plumrocket PrivateSale Images');
        $installer->getConnection()->createTable($table);

        $table = $installer->getConnection()
            ->newTable($installer->getTable('plumrocket_privatesale_emailtemplates'))
            ->addColumn(
                'id',
                Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'ID'
            )
            ->addColumn(
                'name',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Name'
            )
            ->addColumn(
                'store_id',
                Table::TYPE_INTEGER,
                null,
                [],
                'Store Id'
            )
            ->addColumn(
                'date',
                Table::TYPE_DATETIME,
                null,
                [],
                'Date'
            )
            ->addColumn(
                'categories_ids',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Categories Ids'
            )
            ->addColumn(
                'title',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Title'
            )
            ->addColumn(
                'period_text',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Period Text'
            )
            ->addColumn(
                'template',
                Table::TYPE_TEXT,
                null,
                ['nullable' => false],
                'Template'
            )
            ->addColumn(
                'template_date_format',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Template Date Format'
            )
            ->addColumn(
                'list_layout',
                Table::TYPE_INTEGER,
                11,
                [],
                'List Layout'
            )
            ->addColumn(
                'list_template',
                Table::TYPE_TEXT,
                null,
                [],
                'List Template'
            )
            ->addColumn(
                'list_template_date_format',
                Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'list_template_date_format'
            )
            ->addColumn(
                'created_at',
                Table::TYPE_DATETIME,
                null,
                [],
                'created_at'
            )
            ->addColumn(
                'updated_at',
                Table::TYPE_DATETIME,
                null,
                [],
                'updated_at'
            )
            ->setComment('Plumrocket Private Sales Preview Access Codes');
        $installer->getConnection()->createTable($table);

        $installer->endSetup();
    }
}
