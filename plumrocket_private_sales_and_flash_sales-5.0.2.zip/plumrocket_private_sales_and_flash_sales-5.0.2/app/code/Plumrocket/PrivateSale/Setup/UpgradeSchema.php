<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket_PrivateSale
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\PrivateSale\Setup;

use Magento\Framework\DB\Ddl\Table;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Plumrocket\PrivateSale\Model\ResourceModel\Event;
use Plumrocket\PrivateSale\Setup\Operation\CreateEntityToEventIndexTable;
use Plumrocket\PrivateSale\Setup\Operation\CreateEventStatisticIndexTable;

class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * @var EavTablesSetup
     */
    private $eavTablesSetupFactory;

    /**
     * @var \Plumrocket\PrivateSale\Setup\Operation\CreateEntityToEventIndexTable
     */
    private $createEntityToEventIndexTable;

    /**
     * @var \Plumrocket\PrivateSale\Setup\Operation\CreateEventStatisticIndexTable
     */
    private $createEventStatisticIndexTable;

    /**
     * UpgradeSchema constructor.
     *
     * @param \Plumrocket\PrivateSale\Setup\EavTablesSetupFactory                    $eavTablesSetupFactory
     * @param \Plumrocket\PrivateSale\Setup\Operation\CreateEntityToEventIndexTable  $createEntityToEventIndexTable
     * @param \Plumrocket\PrivateSale\Setup\Operation\CreateEventStatisticIndexTable $createEventStatisticIndexTable
     */
    public function __construct(
        EavTablesSetupFactory $eavTablesSetupFactory,
        CreateEntityToEventIndexTable $createEntityToEventIndexTable,
        CreateEventStatisticIndexTable $createEventStatisticIndexTable
    ) {
        $this->eavTablesSetupFactory = $eavTablesSetupFactory;
        $this->createEntityToEventIndexTable = $createEntityToEventIndexTable;
        $this->createEventStatisticIndexTable = $createEventStatisticIndexTable;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @throws \Zend_Db_Exception
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();

        $connection = $setup->getConnection();

        if (version_compare($context->getVersion(), '5.0.0', '<')) {
            $eventEntity = \Plumrocket\PrivateSale\Model\Event::ENTITY;
            $table = $setup->getConnection()
                ->newTable($setup->getTable($eventEntity . '_entity'))
                ->addColumn(
                    'entity_id',
                    Table::TYPE_INTEGER,
                    null,
                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Entity ID'
                )
                ->addColumn(
                    'event_type',
                    Table::TYPE_INTEGER,
                    null,
                    ['nullable' => false],
                    'Event Type'
                )
                ->addColumn(
                    'created_at',
                    Table::TYPE_TIMESTAMP,
                    null,
                    ['nullable' => false, 'default' => Table::TIMESTAMP_INIT],
                    'Creation Time'
                )
                ->addColumn(
                    'updated_at',
                    Table::TYPE_TIMESTAMP,
                    null,
                    ['nullable' => false, 'default' => Table::TIMESTAMP_INIT_UPDATE],
                    'Update Time'
                )
                ->setComment('Plumrocket PrivateSale Event Entities');

            $setup->getConnection()->createTable($table);

            //Create Additional EAV Attributes Table
            $table = $setup->getConnection()
                ->newTable($setup->getTable($eventEntity . '_eav_attribute'))
                ->addColumn(
                    'attribute_id',
                    Table::TYPE_SMALLINT,
                    null,
                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Attribute ID'
                )
                ->addColumn(
                    'is_global',
                    Table::TYPE_SMALLINT,
                    null,
                    ['identity' => false, 'unsigned' => true, 'nullable' => false],
                    'Is Global'
                )
                ->addForeignKey(
                    $setup->getFkName($eventEntity . '_eav_attribute', 'attribute_id', 'eav_attribute', 'attribute_id'),
                    'attribute_id',
                    $setup->getTable('eav_attribute'),
                    'attribute_id',
                    Table::ACTION_CASCADE
                )
                ->setComment('Plumrocket PrivateSale EAV Attributes');

            $setup->getConnection()->createTable($table);

            //Create Value Tables
            /** @var \Plumrocket\PrivateSale\Setup\EavTablesSetup $eavTablesSetup */
            $eavTablesSetup = $this->eavTablesSetupFactory->create(['setup' => $setup]);
            $eavTablesSetup->createEavTables($eventEntity);

            // Create Flash Sale table
            $table = $setup->getConnection()
                ->newTable($setup->getTable('plumrocket_privatesale_flash_sale'))
                ->addColumn(
                    'sale_id',
                    Table::TYPE_INTEGER,
                    11,
                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Unique identifier'
                )->addColumn(
                    'product_id',
                    Table::TYPE_INTEGER,
                    11,
                    ['unsigned' => true, 'nullable' => false],
                    'Product Identifier'
                )->addColumn(
                    'event_id',
                    Table::TYPE_INTEGER,
                    11,
                    ['unsigned' => true, 'nullable' => true],
                    'Event Identifier'
                )->addColumn(
                    'discount_amount_percent',
                    Table::TYPE_DECIMAL,
                    [10, 2],
                    ['nullable' => true],
                    'Discount Amount Percent'
                )->addColumn(
                    'sale_price',
                    Table::TYPE_DECIMAL,
                    [10, 2],
                    ['nullable' => true, 'default' => null],
                    'Flash Sale Price'
                )->addColumn(
                    'flash_sale_qty_limit',
                    Table::TYPE_INTEGER,
                    6,
                    ['nullable' => true, 'default' => null],
                    'Flash Sale QTY Limit'
                )->addForeignKey(
                    $setup->getFkName(
                        $setup->getTable('plumrocket_privatesale_flash_sale'),
                        'product_id',
                        $setup->getTable('catalog_product_entity'),
                        'entity_id'
                    ),
                    'product_id',
                    $setup->getTable('catalog_product_entity'),
                    'entity_id',
                    Table::ACTION_CASCADE
                )->addForeignKey(
                    $setup->getFkName(
                        $setup->getTable('plumrocket_privatesale_flash_sale'),
                        'event_id',
                        $setup->getTable(Event::MAIN_TABLE_NAME),
                        'entity_id'
                    ),
                    'event_id',
                    $setup->getTable(Event::MAIN_TABLE_NAME),
                    'entity_id',
                    Table::ACTION_CASCADE
                )->setComment('Flash Sale');

            $setup->getConnection()->createTable($table);

            //Create Event Statistics Table
            $table = $setup->getConnection()
                ->newTable($setup->getTable('plumrocket_privatesale_event_statistics'))
                ->addColumn(
                    'entity_id',
                    Table::TYPE_INTEGER,
                    11,
                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Unique identifier'
                )->addColumn(
                    'event_id',
                    Table::TYPE_INTEGER,
                    11,
                    ['unsigned' => true, 'nullable' => false],
                    'Event Identifier'
                )->addColumn(
                    'customer_id',
                    Table::TYPE_INTEGER,
                    11,
                    ['unsigned' => true, 'nullable' => true],
                    'Customer Identifier'
                )->addColumn(
                    'order_id',
                    Table::TYPE_INTEGER,
                    11,
                    ['unsigned' => true, 'nullable' => true],
                    'Order Identifier'
                )->addColumn(
                    'item_id',
                    Table::TYPE_INTEGER,
                    11,
                    ['unsigned' => true, 'nullable' => true],
                    'Item Identifier'
                )->addColumn(
                    'created_date',
                    Table::TYPE_DATETIME,
                    null,
                    ['nullable' => false],
                    'Created Date'
                )->setComment('Event Statistics');

            $setup->getConnection()->createTable($table);

            //Create Special Price Storage Table
            $table = $setup->getConnection()
                ->newTable($setup->getTable('plumrocket_privatesale_special_price_storage'))
                ->addColumn(
                    'price_id',
                    Table::TYPE_INTEGER,
                    11,
                    ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                    'Price ID'
                )->addColumn(
                    'sku',
                    Table::TYPE_TEXT,
                    64,
                    ['nullable' => true, 'default' => null],
                    'SKU'
                )->addColumn(
                    'special_price_value',
                    Table::TYPE_DECIMAL,
                    null,
                    ['unsigned' => true, 'nullable' => true],
                    'Origin Special Price'
                )->addColumn(
                    'website_id',
                    Table::TYPE_INTEGER,
                    null,
                    ['unsigned' => true, 'nullable' => false],
                    'Website ID'
                )->addColumn(
                    'date_from',
                    Table::TYPE_DATETIME,
                    null,
                    ['unsigned' => true, 'nullable' => true],
                    'Date From'
                )->addColumn(
                    'date_to',
                    Table::TYPE_DATETIME,
                    null,
                    ['unsigned' => true, 'nullable' => true],
                    'Date To'
                )->addForeignKey(
                    $setup->getFkName(
                        $setup->getTable('plumrocket_privatesale_special_price_storage'),
                        'sku',
                        $setup->getTable('catalog_product_entity'),
                        'sku'
                    ),
                    'sku',
                    $setup->getTable('catalog_product_entity'),
                    'sku',
                    Table::ACTION_CASCADE
                )->setComment('Special Price Storage');

            $connection->createTable($table);

            $productIndexerTable = $setup->getTable('plumrocket_privatesale_product_indexer');

            if ($setup->tableExists($productIndexerTable)) {
                $connection->dropTable($productIndexerTable);
            }

            $emailTableName = $setup->getTable('plumrocket_privatesale_emailtemplates');
            if ($connection->tableColumnExists($emailTableName, 'categories_ids')) {
                $connection->changeColumn(
                    $emailTableName,
                    'categories_ids',
                    'events_ids',
                    ['comment' => 'Events Ids', 'type' => Table::TYPE_TEXT, 'length' => 255]
                );
            }

            //Create Active Events Indexer Table
            $this->createEventIndexerTable(
                $setup,
                'plumrocket_privatesale_product_event_indexer',
                'Active Events Indexer'
            );

            //Create Upcoming Events Indexer Table
            $this->createEventIndexerTable(
                $setup,
                'plumrocket_privatesale_product_upcoming_event_indexer',
                'Upcoming Events Indexer'
            );

            //Create Ended Events Indexer Table
            $this->createEventIndexerTable(
                $setup,
                'plumrocket_privatesale_product_ended_event_indexer',
                'Ended Events Indexer'
            );

            $this->createEntityToEventIndexTable->execute($setup);
            $this->createEventStatisticIndexTable->execute($setup);
        }

        $setup->endSetup();
    }

    /**
     * @param $setup
     * @param $tableName
     * @param $tableComment
     */
    private function createEventIndexerTable($setup, $tableName, $tableComment)
    {
        $table = $setup->getConnection()
            ->newTable($setup->getTable($tableName))
            ->addColumn(
                'product_id',
                Table::TYPE_INTEGER,
                11,
                ['unsigned' => true, 'nullable' => false, 'primary' => true],
                'Product Identifier'
            )->addColumn(
                'website_id',
                Table::TYPE_SMALLINT,
                5,
                ['unsigned' => true, 'nullable' => false, 'primary' => true],
                'Website Identifier'
            )->addColumn(
                'event_id',
                Table::TYPE_INTEGER,
                11,
                ['unsigned' => true, 'nullable' => false],
                'Event Identifier'
            )->addColumn(
                'is_private',
                Table::TYPE_BOOLEAN,
                1,
                ['unsigned' => true, 'nullable' => false],
                'Event Identifier'
            )->addColumn(
                'start_date',
                Table::TYPE_DATETIME,
                null,
                ['nullable' => true],
                'Event Start Date'
            )->addColumn(
                'end_date',
                Table::TYPE_DATETIME,
                null,
                ['nullable' => true],
                'Event End Date'
            )->addForeignKey(
                $setup->getFkName(
                    $setup->getTable($tableName),
                    'event_id',
                    $setup->getTable(Event::MAIN_TABLE_NAME),
                    'entity_id'
                ),
                'event_id',
                $setup->getTable(Event::MAIN_TABLE_NAME),
                'entity_id',
                Table::ACTION_CASCADE
            )->addForeignKey(
                $setup->getFkName(
                    $setup->getTable($tableName),
                    'product_id',
                    $setup->getTable('catalog_product_entity'),
                    'entity_id'
                ),
                'product_id',
                $setup->getTable('catalog_product_entity'),
                'entity_id',
                Table::ACTION_CASCADE
            )->addForeignKey(
                $setup->getFkName(
                    $setup->getTable($tableName),
                    'website_id',
                    $setup->getTable('store_website'),
                    'website_id'
                ),
                'website_id',
                $setup->getTable('store_website'),
                'website_id',
                Table::ACTION_CASCADE
            )->setComment($tableComment);

        $setup->getConnection()->createTable($table);
    }
}
