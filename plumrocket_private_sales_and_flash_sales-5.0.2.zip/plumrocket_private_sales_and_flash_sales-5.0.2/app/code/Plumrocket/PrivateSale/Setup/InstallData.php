<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket Private Sales and Flash Sales v4.x.x
 * @copyright   Copyright (c) 2016 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

namespace Plumrocket\PrivateSale\Setup;

use Magento\Cms\Model\Page as CmsPage;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallData implements InstallDataInterface
{
    /**
     * Email template
     * @var \Plumrocket\PrivateSale\Model\Emailtemplate
     */
    private $emailtemplate;

    /**
     * Email template data
     * @var EmailTemplateData
     */
    protected $emailTemplateData;

    /**
     * Page factory
     * @var \Magento\Cms\Model\PageFactory
     */
    protected $pageFactory;

    /**
     * Product meta data
     * @var \Magento\Framework\App\ProductMetadataInterface
     */
    protected $productMetadata;

    /**
     * InstallData constructor.
     *
     * @param \Plumrocket\PrivateSale\Model\EmailtemplateFactory $emailtemplate
     * @param \Magento\Framework\App\ProductMetadataInterface    $productMetadata
     * @param \Magento\Cms\Model\PageFactory                     $pageFactory
     * @param EmailTemplateData                                  $emailTemplateData
     * @param \Magento\Framework\App\State                       $state
     */
    public function __construct(
        \Plumrocket\PrivateSale\Model\EmailtemplateFactory $emailtemplate,
        \Magento\Framework\App\ProductMetadataInterface $productMetadata,
        \Magento\Cms\Model\PageFactory $pageFactory,
        EmailTemplateData $emailTemplateData,
        \Magento\Framework\App\State $state
    ) {
        try {
            $state->setAreaCode('adminhtml');
        } catch (LocalizedException $e) {
        }
        $this->pageFactory = $pageFactory;
        $this->productMetadata = $productMetadata;
        $this->emailtemplate = $emailtemplate;
        $this->emailTemplateData = $emailTemplateData;
    }

    /**
     * Install Data
     * @param  ModuleDataSetupInterface $setup
     * @param  ModuleContextInterface   $context
     * @return void
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context)
    {
        $this->emailtemplate->create()
            ->setData(
                [
                    'name' => 'One Event in Row',
                    'template' => $this->emailTemplateData->getDefaultEmailTemplate(),
                    'list_template' => $this->emailTemplateData->getListTemplateOne(),
                    'list_template_date_format' => 'm/d/Y',
                    'list_layout' => '1'
                ]
            )->save();

        $this->emailtemplate->create()
            ->setData(
                [
                    'name' => 'Two Event in Row',
                    'template' => $this->emailTemplateData->getDefaultEmailTemplate(),
                    'list_template' => $this->emailTemplateData->getListTemplateTwo(),
                    'list_template_date_format' => 'm/d/Y',
                    'list_layout' => '2'
                ]
            )->save();

        $this->emailtemplate->create()
            ->setData(
                [
                    'name' => 'Three Event in Row',
                    'template' => $this->emailTemplateData->getDefaultEmailTemplate(),
                    'list_template' => $this->emailTemplateData->getListTemplateThree(),
                    'list_template_date_format' => 'm/d/Y',
                    'list_layout' => '3'
                ]
            )->save();

        $this->pageFactory->create()
            ->setData(
                [
                    CmsPage::IS_ACTIVE   => false,
                    CmsPage::IDENTIFIER  => 'flash-sales-homepage',
                    CmsPage::TITLE       => 'Private Sales Homepage',
                    CmsPage::CONTENT     => $this->getHomepageContent(),
                    CmsPage::PAGE_LAYOUT => '1column'

                ]
            )->save();
    }

    /**
     * Retrieve homepage xml
     * @return string
     */
    private function getHomepageContent()
    {
        return '<div class="shops-holder pps-container endingsoon">' .
            '{{widget type="Plumrocket\PrivateSale\Block\Event\Widget\Active" exclude_ending_soon="1" template="Plumrocket_PrivateSale::homepage/event/group.phtml"}} ' .
            '{{widget type="Plumrocket\PrivateSale\Block\Homepage\Endingsoon" block_title="Ending Soon" template="Plumrocket_PrivateSale::homepage/event/default.phtml"}} ' .
            '{{widget type="Plumrocket\PrivateSale\Block\Homepage\Comingsoon" block_title="Coming Soon" template="Plumrocket_PrivateSale::homepage/event/default.phtml"}}' .
            '</div>';
    }
}
