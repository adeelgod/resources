<?php
/**
 * Plumrocket Inc.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the End-user License Agreement
 * that is available through the world-wide-web at this URL:
 * http://wiki.plumrocket.net/wiki/EULA
 * If you are unable to obtain it through the world-wide-web, please
 * send an email to support@plumrocket.com so we can send you a copy immediately.
 *
 * @package     Plumrocket Private Sales
 * @copyright   Copyright (c) 2020 Plumrocket Inc. (http://www.plumrocket.com)
 * @license     http://wiki.plumrocket.net/wiki/EULA  End-user License Agreement
 */

declare(strict_types=1);

namespace Plumrocket\PrivateSale\Test\Unit\Block\Model\Data;

use Plumrocket\PrivateSale\Model\Config\Source\SplashPageAccess;
use Plumrocket\PrivateSale\Model\Data\Migration;
use Plumrocket\PrivateSale\Api\EventRepositoryInterface;
use Plumrocket\PrivateSale\Model\Splashpage as SplashpageModel;
use Plumrocket\PrivateSale\Api\Data\EventInterfaceFactory;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollectionFactory;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Psr\Log\LoggerInterface;

/**
 * @covers \Plumrocket\PrivateSale\Model\Data\Migration
 */
class MigrationTest extends \PHPUnit\Framework\TestCase
{
    /**
     * @var \Plumrocket\PrivateSale\Model\Splashpage|\PHPUnit_Framework_MockObject_MockObject
     */
    private $splashPage;

    /**
     * @var \Plumrocket\PrivateSale\Model\Data\Migration|\PHPUnit_Framework_MockObject_MockObject
     */
    private $migrationModel;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Category\CollectionFactory|\PHPUnit\Framework\MockObject\MockObject
     */
    private $categoryCollectionFactory;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory|\PHPUnit\Framework\MockObject\MockObject
     */
    private $productCollectionFactory;

    /**
     * @var \Plumrocket\PrivateSale\Api\Data\EventInterfaceFactory|\PHPUnit\Framework\MockObject\MockObject
     */
    private $eventFactory;

    /**
     * @var \Plumrocket\PrivateSale\Api\EventRepositoryInterface|\PHPUnit\Framework\MockObject\MockObject
     */
    private $eventRepository;

    /**
     * @var \Psr\Log\LoggerInterface|\PHPUnit\Framework\MockObject\MockObject
     */
    private $logger;

    protected function setUp()
    {
        $this->categoryCollectionFactory = $this->getMockBuilder(CategoryCollectionFactory::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->productCollectionFactory = $this->getMockBuilder(ProductCollectionFactory::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->eventFactory = $this->getMockBuilder(EventInterfaceFactory::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->eventRepository = $this->getMockBuilder(EventRepositoryInterface::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->logger = $this->getMockBuilder(LoggerInterface::class)
            ->disableOriginalConstructor()
            ->getMock();

        $this->splashPage = $this->getMockBuilder(SplashpageModel::class)
            ->disableOriginalConstructor()
            ->setMethods(['setData', 'getData', 'save'])
            ->getMock();

        $objectManager = new \Magento\Framework\TestFramework\Unit\Helper\ObjectManager($this);

        $this->migrationModel = $objectManager->getObject(
            Migration::class,
            [
                'categoryCollectionFactory' => $this->categoryCollectionFactory,
                'productCollectionFactory' => $this->productCollectionFactory,
                'eventFactory' => $this->eventFactory,
                'eventRepository' => $this->eventRepository,
                'logger' => $this->logger,
                'splashpage' => $this->splashPage,
            ]
        );
    }

    /**
     * @covers \Plumrocket\PrivateSale\Model\Data\Migration::migrationSplashPageProcess
     * @dataProvider getSplashPageData
     */
    public function testMigrationSplashPageProcess($oldData, $newData)
    {
        $this->splashPage->expects($this->once())
            ->method('getData')
            ->willReturn($oldData);

        $this->splashPage->expects($this->once())
            ->method('save')
            ->will($this->returnSelf());

        $this->splashPage->expects($this->once())
            ->method('setData')
            ->with($this->equalTo($newData))
            ->will($this->returnSelf());

        $this->migrationModel->migrationSplashPageProcess();
    }

    /**
     * @return array
     */
    public function getSplashPageData()
    {
        return [
            [
                [
                    'enabled_page' => '1',
                    'become_text' => 'Some text',
                    'launching_text' => 'Some text',
                    'enabled_registration' => '1',
                    'is_new_files' => '1'
                ],
                [
                    'enabled' => '1',
                    'form_text' => 'Some text',
                    'confirmation_text' => 'Some text',
                    'access' => SplashPageAccess::REGISTER,
                    'is_new_files' => '0'
                ],
            ],
            [
                [
                    'enabled_page' => '1',
                    'become_text' => 'Some text',
                    'launching_text' => 'Some text',
                    'enabled_registration' => '0',
                ],
                [
                    'enabled' => '1',
                    'form_text' => 'Some text',
                    'confirmation_text' => 'Some text',
                    'access' => SplashPageAccess::LOGIN_AND_REGISTER,
                ],
            ],
            [
                [
                    'become_text' => 'Some text',
                    'launching_text' => 'Some text',
                ],
                [
                    'form_text' => 'Some text',
                    'confirmation_text' => 'Some text',
                ],
            ],
            [
                [
                    'another_field' => 'Some text',
                ],
                [
                    'another_field' => 'Some text',
                ],
            ]
        ];
    }
}
