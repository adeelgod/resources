var config = {
    map: {
        '*': {
            'emailtemplateEdit': 'Plumrocket_PrivateSale/js/emailtemplate',
            'splashpage': 'Plumrocket_PrivateSale/js/splashpage'
        }
    }
};
